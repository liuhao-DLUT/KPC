function [new_x,dmodel]=multi_WEGO(S,Y,regr, corr,searchfun,Max,Min,OptFun,R_kpc)
[~,dim]=size(S);
lob=1E-6*ones(1,dim);
upb=100*ones(1,dim);
%%
[dmodel,~] = modelfit_KPC(S, Y, regr, corr, R_kpc);
Ymin=min(Y);
[peaks]=searchfun(OptFun,dmodel,Ymin,dim,Max,Min);
new_x=peaks;
if isempty(peaks) 
   return;
end

