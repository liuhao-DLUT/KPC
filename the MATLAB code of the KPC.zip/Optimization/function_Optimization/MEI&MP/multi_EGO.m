function [new_x,dmodel]=multi_WEGO(S,Y,regr, corr,searchfun,Max,Min,OptFun,R_XG)
[~,dim]=size(S);
lob=1E-8*ones(1,dim);
upb=100*ones(1,dim);
%%
[dmodel,~] = modelfit_KPC(S, Y, regr, corr, R_kpc);
% [dmodel,~] = modelfit_KDIC(S, Y, regr, corr, lob, upb, R_XG);
% [dmodel,~] = modelfit_KMIC(S, Y, regr, corr, R_mic);
Ymin=min(Y);
[peaks]=searchfun(OptFun,dmodel,Ymin,dim,Max,Min);
new_x=peaks;
if isempty(peaks) 
   return;
end

