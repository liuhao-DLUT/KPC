%Generation of offspring, and judge whether at the same peak, select individuals with higher fitness to the next generation
function [elitist,badparents]=AdapElitist(p1,p2,threshold,Max,Min,theta,oldElitists,dmodel,Ymin,OptFun)
%input       :
%p1,p2       :Parent
%threshold   :Peak threshold
%Max,Min     :The range of variation of the independent variable
%theta       :Produces a step factor to judge progeny
%oldElitists :Primitive elite group
%output      :
%elitist     :For selected elite individuals, size(elitist,1)=2 if there are two peaks.
%badparents  :the unqualified parent
dim=size(p1,2)-1;
flag1=ones(1,dim);
flag2=ones(1,dim);
elitist=[];
badparents=[];
%%
%Produce offspring
c1=zeros(size(p1));
while sum(flag1)~=0
    f1=rand(1)-0.5;
    c1(1,1:end-1)=p1(1,1:end-1)+f1*(p2(1,1:end-1)-p1(1,1:end-1));
    for i=1:dim
        if Min(i)<=c1(i)&&c1(i)<=Max(i)
            flag1(i)=0;
        else
            flag1(i)=1;
        end
    end
end
c2=zeros(size(p2));
while sum(flag2)~=0
    f2=rand(1)-0.5;
    c2(1,1:end-1)=p2(1,1:end-1)+f2*(p1(1,1:end-1)-p2(1,1:end-1));
    for i=1:dim
        if Min(i)<=c2(i)&&c2(i)<=Max(i)
            flag2(i)=0;
        else
            flag2(i)=1;
        end
    end
end
c1(1,end)=OptFun(c1(1:end-1),dmodel,Ymin);
c2(1,end)=OptFun(c2(1:end-1),dmodel,Ymin);
%%
%Calculation of distance
d1=distance(p1(1,1:end-1),p2(1,1:end-1));d2=distance(p1(1,1:end-1),c1(1,1:end-1));
d3=distance(p1(1,1:end-1),c2(1,1:end-1));d4=distance(p2(1,1:end-1),c1(1,1:end-1));
d5=distance(p2(1,1:end-1),c2(1,1:end-1));d6=distance(c1(1,1:end-1),c2(1,1:end-1));
D=[d1;d2;d3;d4;d5;d6];
[d,indexd]=max(D);
%%
  [pointdirection1]=directioncheck(p1,p2,theta,dmodel,Ymin,OptFun);
  [pointdirection2]=directioncheck(p1,c1,theta,dmodel,Ymin,OptFun);
  [pointdirection3]=directioncheck(p1,c2,theta,dmodel,Ymin,OptFun);
  [pointdirection4]=directioncheck(p2,c1,theta,dmodel,Ymin,OptFun);
  [pointdirection5]=directioncheck(p2,c2,theta,dmodel,Ymin,OptFun);
  [pointdirection6]=directioncheck(c1,c2,theta,dmodel,Ymin,OptFun);
  B=[p1;p2;p1;c1;p1;c2;p2;c1;p2;c2;c1;c2];  
if d<=threshold
  if pointdirection1~=2&&pointdirection2~=2&&pointdirection3~=2&&pointdirection4~=2&&pointdirection5~=2&&pointdirection6~=2
      if pointdirection1==0&&pointdirection2==0&&pointdirection3==0&&pointdirection4==0&&pointdirection5==0&&pointdirection6==0
          elitist(1,:)=B(indexd,:);
          elitist(2,:)=B(indexd+1,:);
      else 
       A=[p1;p2;c1;c2];
      [~,index]=max(A(:,end));
      elitist(1,:)=A(index,:);
      end
  else
            if  p1(end)>c1(end)
                elitist(1,:)=p1;
            else
                elitist(1,:)=c1;
                       [~,~,badparent]=FindCloseElitist(c1,oldElitists,theta,threshold,dmodel,Ymin,OptFun);
                       badparents=[badparents;badparent;p1];
            end
            if  p2(end)>c2(end)
                elitist(2,:)=p2;
            else
                elitist(2,:)=c2;
                      [~,~,badparent]=FindCloseElitist(c2,oldElitists,theta,threshold,dmodel,Ymin,OptFun);
                      badparents=[badparents;badparent;c2];
            end   
  end
else 
     if pointdirection2==2
         elitist(1,:)=p1;
               [~,stay,badparent]=FindCloseElitist(c1,oldElitists,theta,threshold,dmodel,Ymin,OptFun);
               badparents=[badparents;badparent];
             if stay==1
                elitist(2,:)=c1;
             else
                elitist=elitist;
             end
         if pointdirection5==2
             elitist=[elitist;p2];
          % Determine if offspring conflict with other elite individuals
          [~,stay,badparent]=FindCloseElitist(c2,oldElitists,theta,threshold,dmodel,Ymin,OptFun);
          badparents=[badparents;badparent];
              if stay==1   
                 elitist=[elitist;c2];
              else
                  elitist=elitist;
              end
         else
             if  p2(end)>c2(end)
                 elitist=[elitist;p2]; 
             else
                 elitist=[elitist;c2]; 
                       [~,~,badparent]=FindCloseElitist(c1,oldElitists,theta,threshold,dmodel,Ymin,OptFun);
                       badparents=[badparents;badparent;p2];
             end
         end
     else
            if  p1(end)>c1(end)
                elitist(1,:)=p1;
            else
                elitist(1,:)=c1;
                       [~,~,badparent]=FindCloseElitist(c1,oldElitists,theta,threshold,dmodel,Ymin,OptFun);
                       badparents=[badparents;badparent;p1];
            end
            if pointdirection5==2
               elitist=[elitist;p2];  
           % Determine if offspring conflict with other elite individuals
          [~,stay,badparent]=FindCloseElitist(c2,oldElitists,theta,threshold,dmodel,Ymin,OptFun);
           badparents=[badparents;badparent];
              if stay==1   
                 elitist=[elitist;c2];
              else
                  elitist=elitist;
              end

            else
              if  p2(end)>c2(end)
                  elitist=[elitist;p2]; 
              else
                  elitist=[elitist;c2]; 
                      [~,~,badparent]=FindCloseElitist(c2,oldElitists,theta,threshold,dmodel,Ymin,OptFun);
                      badparents=[badparents;badparent;p2];
              end
            end
     end 
end
