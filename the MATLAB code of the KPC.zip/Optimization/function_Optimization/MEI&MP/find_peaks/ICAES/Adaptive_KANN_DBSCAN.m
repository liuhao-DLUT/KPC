function peaks_zong=Adaptive_KANN_DBSCAN(x)
peaks_zong=[];
for jj=1:100
       [peaks,noise]=KANN_DBSCAN(x);
       if isempty(peaks)
           break
       end
       peaks_zong=[peaks_zong;peaks];
       x=noise;
       [index_jing,~]=find(x(:,end)==max(peaks_zong(:,end)));
        if ~isempty(index_jing)
            x(index_jing,:)=[];
        end
        [N_jingyin ~]=size(x);
        if N_jingyin<10
           break
        end
       [N_peaks,~]=size(peaks_zong);
       if N_peaks>5
           break
       end
end
peaks_zong=unique(peaks_zong,'rows');
[N_peaks,~]=size(peaks_zong);
if N_peaks>5
   peaks_zong=peaks_zong(1:5,:);
end 
end