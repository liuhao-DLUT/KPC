function [peaks_zong,noise]=KANN_DBSCAN(x)
%input:
%     x     :The data set
%output:
%     eps   :The estimate the radius
%     minPts:The estimated minimum number of points
peaks_zong=[];stop=0;
%% distance
Sample_Num=size(x,1);
Sample_dim=size(x,2);
for ii=1:Sample_Num
    for jj=ii:Sample_Num
        ED(ii,jj)=norm(x(ii,1:end-1)-x(jj,1:end-1));
    end
end
for ii=1:Sample_Num
    for jj=ii:Sample_Num
        ED(jj,ii)=ED(ii,jj);
    end
end
%% Find the Eps parameter list
ED=sort(ED,2);
Dk_mean=mean(ED);
Eps_list=Dk_mean;
%% Find the MinPts_list parameter list
for ii=1:Sample_Num
    R=Dk_mean(ii);
    for jj=1:Sample_Num
        Yunei=find(ED(jj,:)<=R);
        P(jj)=size(Yunei,2)-1;
    end
    MinPts_list(ii)=1/Sample_Num.*sum(P);
    eps=Eps_list(ii);MinPts=MinPts_list(ii);
    [peaks,noise1]=DBSCAN(x,eps,MinPts);
    [N(ii) dim]=size(peaks);
    if ii>3
        if max(N(ii-2:ii))-min(N(ii-2:ii))<5
            stop=ii;
            break;
        end
    end
end
%% Convergence condition
if stop==0
    stop=Sample_Num;
end
%% output
eps=Eps_list(stop);MinPts= floor(MinPts_list(stop));
[peaks_zong,noise]=DBSCAN(x,eps,MinPts);
peaks_zong=unique(peaks_zong,'rows');