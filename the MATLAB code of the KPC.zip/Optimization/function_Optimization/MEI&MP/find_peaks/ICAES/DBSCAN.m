%DBSCAN density clustering
function [peaks,noise]=DBSCAN(Elitists,Eps,MinPts)
% input:
% Elitists       : The data to be classified is classified by the distance of variable values, excluding the response value
% output:
% peaks          : Peak location and response value
data=Elitists(:,1:end-1);
peaks=[];
[m,~] = size(data);
x = [(1:m)' data];  
[m,n] = size(x);            %Recalculate the size of the dataset
types = zeros(1,m);         %Used to distinguish core point 1, boundary point 0 and noise point -1
dealed = zeros(m,1);        %Used to determine whether the point has been processed. 0 indicates that the point has not been processed
dis = calDistance(x(:,2:n));  
number = 1;
%%  deal with each point
class=[];
for i = 1:m  
    %Find the unprocessed point
    if dealed(i) == 0  
        xTemp = x(i,:);  
        D = dis(i,:);%Take the distance from the ith point to all the other points
        ind = find(D<=Eps);%��Find all points within radius Eps
        %% Distinguish the types of points
        % the boundary point
        if length(ind) > 1 && length(ind) < MinPts+1  
            types(i) = 0;  
            class(i) = 0;  
        end  
        % the noise points
        if length(ind) == 1  
            types(i) = -1;  
            class(i) = -1;  
            dealed(i) = 1;  
        end  
        % the core point
        if length(ind) >= MinPts+1  
            types(xTemp(1,1)) = 1;  
            class(ind) = number;    
            % Determine whether the density of the core point is accessible
            while ~isempty(ind)  
                yTemp = x(ind(1),:);  
                dealed(ind(1)) = 1;  
                ind(1) = [];  
                D = dis(yTemp(1,1),:);
                ind_1 = find(D<=Eps);  
                    class(ind_1) = number;  
                    if length(ind_1) >= MinPts+1  
                        types(yTemp(1,1)) = 1;  
                    else  
                        types(yTemp(1,1)) = 0;  
                    end  
                      
                    for j=1:length(ind_1)  
                       if dealed(ind_1(j)) == 0  
                          dealed(ind_1(j)) = 1;  
                          ind=[ind ind_1(j)];     
                       end                      
                   end  
            end  
            number = number + 1;  
        end  
    end  
end  
% all unclassified points are treated as noise points
ind_2 = find(class==0);  
class(ind_2) = -1;  
types(ind_2) = -1;  
%%
Class_Elitist=[class' Elitists];
for i=1:number-1
    Cindex=find(Class_Elitist(:,1)==i);
    peakf=max(Elitists(Cindex,end));
    [~,index]=ismember(peakf,Elitists(:,end));
    peak=Elitists(index,:);
    peaks=[peaks;peak];
end
%% Output noise point
noise=[];
noise_Index=find(Class_Elitist(:,1)==-1);
noise=Elitists(noise_Index,:);
%%
%Find out the outlier sample point fitness of the individuals
 Lq=find(Class_Elitist(:,1)==-1);
if ~isempty(peaks) && ~isempty(Lq)
    [~,max_peak_id]=max(peaks(:,end));
    max_peak=peaks(max_peak_id,:);
    Lq_persons=Elitists(Lq,:);
   [Lq_f,Lq_id]=max(Lq_persons(:,end));
   max_Lq=Lq_persons(Lq_id,:);
   if Lq_f>max_peak(:,end)
       peaks=[peaks;max_Lq];
   end
   peaks=unique(peaks,'rows');
end
