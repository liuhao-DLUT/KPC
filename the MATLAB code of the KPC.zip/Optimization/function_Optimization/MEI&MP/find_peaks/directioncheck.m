%Determine the rising direction of position x
function [pointdirection]=directioncheck(xi,xj,theta,dmodel,Ymin,OptFun)
% input
% xi,xj            :��Randomly selected, to be judged whether the same peak
% theta            :Produces a step factor to judge progeny
% output
% pointdirection   :pointdirection==0,flat
%                  :pointdirection==1,face to face 
%                  :pointdirection==2,back to back
%                  :pointdirection==3;flat to upwards/downwards
flagxi=[]; flagxj=[];         % Tags
                              % flagxi=0��The child C has the same P value as the parent
                              % flagxi=1��It is judged that the P value of the offspring C is larger than that of the parent, and the upward direction of the value is pointing to the offspring C
                              % flagxi=-1��t is judged that the P value of the offspring C is smaller than that of the parent, and the upward direction of the value is pointing to the parent P

xi2=xi(1,1:end-1)+theta*(xj(1,1:end-1)-xi(1,1:end-1));
xj2=xj(1,1:end-1)-theta*(xj(1,1:end-1)-xi(1,1:end-1));

dxi=OptFun(xi2,dmodel,Ymin)-xi(end);
if dxi==0
    flagxi=0;
elseif dxi>0
    flagxi=1;
elseif dxi<0
    flagxi=-1;
end

dxj=OptFun(xj2,dmodel,Ymin)-xj(end);
if dxj==0
    flagxj=0;
elseif dxj>0
    flagxj=1;
elseif dxj<0
    flagxj=-1;
end
if (flagxi==1&&flagxj==1)||(flagxi==1&&flagxj==-1)||(flagxi==-1&&flagxj==1)
    pointdirection=1;
elseif flagxi==-1&&flagxj==-1
    pointdirection=2;
elseif flagxi==0&&flagxj==0
    pointdirection=0;
else
    pointdirection=3;
end
    