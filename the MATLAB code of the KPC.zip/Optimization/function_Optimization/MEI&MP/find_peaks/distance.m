function d=distance(x,y)
d=norm(x-y);