%Find the closest individual to the offspring, and determine whether it is the same peak, decide whether to stay
function [closeElitist,stay,badparents]=FindCloseElitist(c,oldElitists,theta,threshold,dmodel,Ymin,OptFun)
%input :
%c              :individuals
%oldElitists    :the elite individuals that exist at this stage
%theta          :Produces a step factor to judge progeny
%threshold      :Peak threshold
%output:
%closeElitist   :The most recent elite individual
%stay:          :Whether to leave offspring
                % stay=1 leave��stay=0 Don't leave
%badparents     :An unqualified parent
[n,~]=size(oldElitists);
Dist=zeros(1,n);
badparents=[];
for i=1:n
    Dist(i)=distance(c(1,1:end-1),oldElitists(i,1:end-1));
end
[minDist,minIndex]=min(Dist);
closeElitist=oldElitists(minIndex,:);
if minDist<threshold
   [pointdirection]=directioncheck(c,closeElitist,theta,dmodel,Ymin,OptFun);
   if pointdirection==2
       stay=1;

   else
       if c(1,end)>closeElitist(1,end)
           stay=1;      % Keep progeny and weed out individuals that are smaller on the same peak
          badparents=closeElitist;
       else
           stay=0;       
       end
   end
else
    stay=1;
end