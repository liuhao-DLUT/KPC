% the ICAES
function [peaks_zong]=multiPeaks(OptFun,dmodel,Ymin,dim,Max,Min)
EItol=10^-4;  
numpop=10;  
threshold=0.01;
theta=0.05;  peaks_zong=[];
maxloop=5;  
inpop=lhsdesign(numpop,dim);
inpopf=OptFun(inpop,dmodel,Ymin);
Elitists=[inpop,inpopf];
oldElitists=Elitists;
countElitist=[];
%% Look for multiple peaks of EI
for loop=1:maxloop
    oldElitists=Elitists;
    NumElitist=size(Elitists,1);
    order=randperm(NumElitist);
    NumPair=(NumElitist-mod(NumElitist,2))/2;
    newElitists=[];NNNN=20;
% Change to parallel strategy to improve computational efficiency,20 at a time, not enough to supplement
    cha_N=NNNN-mod(NumPair,NNNN);
    jia=lhsdesign(cha_N.*2,dim);jiaf=OptFun(jia,dmodel,Ymin);
    jia=[jia,jiaf];
    Elitists=[Elitists;jia];
    NumElitist=size(Elitists,1);
    order=randperm(NumElitist);
    NumPair=(NumElitist-mod(NumElitist,2))/2;
    N_par=NumPair/NNNN;
% Search for the best EI value
    if mod(NumElitist,2)==0
        elitist=[];
        badparents=[];
        for ii=1:N_par
          for p=1:NNNN
              kk=2*p-1;
            p1=Elitists(order(kk),:);
            p2=Elitists(order(kk+1),:);
            [elitistNum,badparentsNum]=AdapElitist(p1,p2,threshold,Max,Min,theta,oldElitists,dmodel,Ymin,OptFun);
            elitist=[elitistNum;elitist];
            badparents=[badparentsNum;badparents];
          end
        end  
        elitist=[elitist;oldElitists];
        elitist=unique(elitist,'rows');
        if ~isempty(badparents)        
            elitist(ismember(elitist,badparents,'rows'),:)=[];
        else
        end
        Elitists=elitist;
% Eliminate the small Elitists
        [index,~]=find(Elitists(:,end)<EItol);
        if ~isempty(index)
            Elitists(index,:)=[];
        end
    else
        elitist=[];
        badparents=[];
        for ii=1:N_par
          for p=1:NNNN
            kk=2*p-1;
            p1=Elitists(order(kk),:);
            p2=Elitists(order(kk+1),:);
            [elitistNum,badparentsNum]=AdapElitist(p1,p2,threshold,Max,Min,theta,oldElitists,dmodel,Ymin,OptFun);
            elitist=[elitistNum;elitist];
            badparents=[badparentsNum;badparents];
            end
        end  
        elitist=[elitist;oldElitists];
        elitist=unique(elitist,'rows');
        if ~isempty(badparents)        
            elitist(ismember(elitist,badparents,'rows'),:)=[];
        else
        end 
        Elitists=[elitist;Elitists(order(end),:)];
% Eliminate the small Elitists
        [index,~]=find(Elitists(:,end)<EItol);
        if ~isempty(index)
            Elitists(index,:)=[];
        end
    end 
    countElitist=[countElitist;Elitists];
end
  if ~isempty(Elitists)
    jingyin_dian=Elitists;
else
    peaks_zong=[];
    return;
  end
%% the adaptive KANN-DBSCAN
peaks_zong=Adaptive_KANN_DBSCAN(jingyin_dian);
