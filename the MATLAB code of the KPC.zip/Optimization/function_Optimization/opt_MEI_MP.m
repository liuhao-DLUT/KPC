clc;clear all;
% The optimization framework based on the KPC model
%% 1 input variable
% dim                           The dimension of the input variable
% Kernel_function               The kernel function for model building
% funaqq                        The function used to compute the true response
% num_initial_sample            The initial number of samples
% lo_dian up_dian               The upper and lower bounds of the variable x,which are generally 0 and 1
% error_EI                      The convergence value of EI sample filling
% error_MP                      The convergence value of MP sample filling
dim=60;
num_initial_sample=dim;         % Set the initial sample points
Kernel_function=@corrgauss;
funaqq=@fun_griewank;             % x needs to be normalized
Max=ones(1,dim);Min=zeros(1,dim);
lo_dian=zeros(dim,1);up_dian=ones(dim,1); 
maxloop=1000;                   % The maximum number of optimization iterations
error_EI=-1E-4;
cha_zhi=1e-2;
%% 1 Latin Hypercube obtains the initial samples
x_initial=lhsdesign(num_initial_sample,dim); 
y_initial=funaqq(x_initial);
%% 2 Calculating projected correlation
R_kpc=PC_XG(x_initial,y_initial);
% R_dic=DIC_XG(x_initial,y_initial);
% R_mic=MIC_XG(x_initial,y_initial);
% global dmodel Ymin
%% 3 Optimization
for outer_loop=1:100
    % The outer loop is used to update the projection correlation
   for inner_loop=1:maxloop
    ymin=min(y_initial)
    % The multi-peaks EI sample infill
    [news_MEI,dmodel]=multi_EGO(x_initial,y_initial,@regpoly0,Kernel_function,@multiPeaks,Max,Min,@EI,R_kpc);
    % The MP sample infill
    funMP=@(x)MP(x,dmodel);
    [news_MP,newY_mp]=ga(funMP,dim,[],[],[],[],lo_dian,up_dian);
    [num_news,~]=size(news_MEI);    
    cha_nei=abs(newY_mp-min(y_initial));
    % Convergence judgment of the inner loop
    if num_news==0
        if cha_nei<=cha_zhi
            break 
        else
            % Supplementary sample points(MP)
            news_MP=[news_MP,newY_mp];news=[news_MEI;news_MP];
            Ynews=funaqq(news(:,1:end-1));
        end
    else
        if cha_nei<=cha_zhi
            % Supplementary sample points(MEI)
            news=news_MEI;
            Ynews=funaqq(news_MEI(:,1:end-1));
        else
            % Supplementary sample points(MEI&MP)
            news_MP=[news_MP,newY_mp];news=[news_MEI;news_MP];
            Ynews=funaqq(news(:,1:end-1));
        end
    end
    loop(outer_loop,inner_loop)=1;
    x_initial=[x_initial;news(:,1:end-1)];y_initial=[y_initial;Ynews];
   end
%--------------------------------------------------------------------
R_kpc=PC_XG(x_initial,y_initial); 
[model_KPC,~] = modelfit_KPC(x_initial,y_initial, @regpoly0, Kernel_function, R_kpc);
% Convergence judgment of the inner loop
[news_MEI,dmodel]=multi_EGO(x_initial,y_initial,@regpoly0,Kernel_function,@multiPeaks,Max,Min,@EI,R_kpc);
[new_mp,Y_mp]=ga(funMP,dim,[],[],[],[],lo_dian,up_dian);
cha_wai=abs(Y_mp-min(y_initial));[Num,~]=size(news_MEI);
if cha_wai<cha_zhi&&Num==0
    break
end
end
%% output
[Num_x]=size(x_initial,1);
Num_infill=Num_x-num_initial_sample;
Opt=min(y_initial);
Index_step=find(loop~=0);Index_Num=max(size(Index_step));
fprintf('The number of filled samples is %8.5f\n',Num_infill)
fprintf('The optimal solution is %8.5f\n',Opt)
fprintf('The iteration number of optimization is %8.5f\n',Index_Num)