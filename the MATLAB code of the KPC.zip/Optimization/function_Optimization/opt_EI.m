clc;clear all;
% The optimization framework based on EGO
%% 1 input variable
% dim                           The dimension of the input variable
% Kernel_function               The kernel function for model building
% funaqq                        The function used to compute the true response
% num_initial_sample            The initial number of samples
% lo_dian up_dian               The upper and lower bounds of the variable x,which are generally 0 and 1
% error_EI                      The convergence value of EI sample filling
% error_MP                      The convergence value of MP sample filling
dim=10;
num_initial_sample=dim;         % Set the initial sample points
Kernel_function=@corrgauss;
funaqq=@fun_sphere;             % x needs to be normalized
Max=ones(1,dim);Min=zeros(1,dim);
lo_dian=zeros(dim,1);up_dian=ones(dim,1); 
lob=1e-8*ones(1,dim);upb=100*ones(1,dim);
maxloop=1000;                   % The maximum number of optimization iterations
error_EI=-1E-4;
cha_zhi=1e-2;
%% 1 Latin Hypercube obtains the initial samples
x_initial=lhsdesign(num_initial_sample,dim); 
y_initial=funaqq(x_initial);
%% 2 Calculating projected correlation
R_kpc=PC_XG(x_initial,y_initial);
R_dic=DIC_XG(x_initial,y_initial);
R_mic=MIC_XG(x_initial,y_initial);
%% 3 Optimization
   for loop=1:maxloop
    ymin=min(y_initial)
    % The construction of the surrogete model: KPC/KMIC/KDIC
%     [dmodel,~] = modelfit_KPC(x_initial, y_initial,@regpoly0,Kernel_function, R_kpc);
%     [dmodel,~] = modelfit_KDIC(x_initial, y_initial,@regpoly0,Kernel_function, lob, upb, R_dic);
    [dmodel,~] = modelfit_KMIC(x_initial, y_initial,@regpoly0,Kernel_function, R_mic);
    
    % The  EI sample infill
    funEI=@(x)EGO(x,dmodel,ymin);
    [news_EI,EI]=ga(funEI,dim,[],[],[],[],lo_dian,up_dian);
    % Convergence judgment of the loop
    if EI>error_EI
            break 
    else
            Ynews=funaqq(news_EI);
    end
    sum_loop(loop)=1;
    x_initial=[x_initial;news_EI];y_initial=[y_initial;Ynews];
   end
%% output
[Num_x]=size(x_initial,1);
Num_infill=Num_x-num_initial_sample;
Opt=min(y_initial);
Index_step=find(sum_loop~=0);Index_Num=max(size(Index_step));
fprintf('The number of filled samples is %8.5f\n',Num_infill)
fprintf('The optimal solution is %8.5f\n',Opt)
fprintf('The iteration number of optimization is %8.5f\n',Index_Num)