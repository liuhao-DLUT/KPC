clear all;clc;
% The construction framework of KPC model
%% input variable
% dim              The dimension of the input variable
% Kernel_function  The kernel function for model building
% funaqq           The function used to compute the true response
% x_train          The training set of the model
% y_train          The real response corresponding to the training set
% x_test           The test set of the model
% y_test           The real response corresponding to the test set
% theta0           The initial value of hyperparameters
% lob upb          The lower and upper limits of hyperparameters optimization for Kriging model
dim=10;
Kernel_function=@corrspline;
funaqq=@fun_F1;    % The test function is F1~7
theta0=1*ones(1,dim);
lob=1e-8*ones(1,dim);
upb=100*ones(1,dim);
%% 1 Latin Hypercube obtains the training and test sets
Num=10*dim;
%   Input variable dimension
%   The number of sample points is 10 times the number of dimensions(10*dim)
x_train=lhsdesign(Num,dim)*10-5; % define the domain of x
for i=1:Num
   y_train(i,1)=funaqq(x_train(i,:));
end
%   The number of sample points in the test set is 20*dim
x_test=lhsdesign(Num,dim)*10-5;
for i=1:Num
   y_test(i,1)=funaqq(x_test(i,:));
end
%% 2 Calculating projected correlation
% The computation time is closely related to the number of samples. When the number of training sets is large, a small number of samples are used to replace them.
% The construction of KPC needs to ensure that x_train has no duplicate data
    if Num>50
       xpc=x_train(1:50,:);ypc=y_train(1:50,:);
       R_kpc=PC_XG(xpc,ypc);
    else
       R_kpc=PC_XG(x_train,y_train);
    end
    R_dic=DIC_XG(x_train,y_train);
    R_mic=MIC_XG(x_train,y_train);
%% 3 The construction of KPC/KDIC/KMIC/DACE model
[KPC_1,~] = modelfit_KPC(x_train, y_train, @regpoly0, Kernel_function, R_kpc);
% The first call to the function takes extra time, so a repetitive modeling process is added
tic;
[KPC,~] = modelfit_KPC(x_train, y_train, @regpoly0, Kernel_function, R_kpc);
time_kpc=toc;tic
[KDIC,~] = modelfit_KDIC(x_train, y_train, @regpoly0, Kernel_function, lob, upb, R_dic);
time_kdic=toc;tic
[KMIC,~] = modelfit_KMIC(x_train, y_train, @regpoly0, Kernel_function, R_mic);
time_kmic=toc;tic
[DACE,~]=dacefit(x_train, y_train, @regpoly0, Kernel_function,theta0, lob, upb);
time_dace=toc;
%% 3 The prediction based on KPC/KDIC/KMIC/DACE model
[y_test_KPC  MSE] = predictor(x_test, KPC);
[y_test_KDIC MSE] = predictor(x_test, KDIC);
[y_test_KMIC MSE] = predictor(x_test, KMIC);
[y_test_DACE MSE] = predictor(x_test, DACE);
%% 4 The error comparison
model={'y_test_KPC' 'y_test_KDIC' 'y_test_KMIC' 'y_test_DACE'};
for i=1:4
    error_r2(i)=R2(eval([cell2mat(model(1,i))]),y_test,x_test);
    error_rmse(i)=RMSE(eval([cell2mat(model(1,i))]),y_test,x_test);
    error_nmae(i)=NMAE(eval([cell2mat(model(1,i))]),y_test,x_test);
end
