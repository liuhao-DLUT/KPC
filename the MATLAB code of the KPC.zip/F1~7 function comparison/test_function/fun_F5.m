function y=fun_Boch(x)
   [N dim]=size(x);
   sum=0;
   for ii=1:dim-1
       yy1=x(:,ii).^2+2.*x(:,ii+1).^2-0.3.*cos(3*pi.*x(:,ii))-0.4.*cos(4*pi.*x(:,ii+1))+0.7;
       sum=sum+yy1;
   end
   y=sum;
end