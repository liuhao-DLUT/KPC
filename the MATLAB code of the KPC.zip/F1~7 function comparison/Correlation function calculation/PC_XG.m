function  PCxy=PCxy_xianguang(X,Y)
%-------------------------------------------
%  XΪ N*p ����    YΪ N*1  
%-------------------------------------------
   [N dim]=size(X);
   PcovYY=qiu_Pcov(Y,Y);
   for p=1:dim
       PcovXX=qiu_Pcov(X(:,p),X(:,p));
       PcovXY=qiu_Pcov(X(:,p),Y);
       PCxy(p)=sqrt(PcovXY^2/(PcovXX*PcovYY));
   end
function  Pcov_xy=qiu_Pcov(XX,YY)
%ͶӰ��ط���1
%------------------------------------------------------
%��Aklr Bklr
[N dim]=size(XX);
    for k=1:N
        for l=1:N
            for r=1:N
                Xk=XX(k,:);Xl=XX(l,:);Xr=XX(r,:);
                Yk=YY(k,:);Yl=YY(l,:);Yr=YY(r,:);
                if k==r||l==r
                    aklr(k,l,r)=0;bklr(k,l,r)=0;
                else
                    aklr(k,l,r)=funcos(Xk,Xl,Xr);
                    bklr(k,l,r)=funcos(Yk,Yl,Yr);
                end
            end
        end
    end
%------------------------------------------------------
%��akl
   akr=mean(aklr,2);alr=mean(aklr,1);ar=mean(mean(aklr,1),2);
   bkr=mean(bklr,2);blr=mean(bklr,1);br=mean(mean(bklr,1),2);
%------------------------------------------------------
   Aklr=aklr-akr-alr+ar;Bklr=bklr-bkr-blr+br;
   c=Aklr.*Bklr;
   Pcov_xy=sqrt(mean(Aklr.*Bklr,'all'));
   
function  aaklr=funcos(Xk1,Xl1,Xr1)
aaklr=acos((Xk1-Xr1)*(Xl1-Xr1)'/(norm(Xk1-Xr1)*norm(Xl1-Xr1)));