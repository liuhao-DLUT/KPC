function  R=fun_dic(X1,Y)
%�������ϵ��
[m dim]=size(X1);
 B=funAzhuan(Y);
 BB=B.^2;
  VYY=mean(BB(:));
 for k=1:dim
     X1(:,1)=X1(:,k);
     AX1=funAzhuan(X1);
     CXY=AX1.*B;
     VXY(k)=mean(CXY(:));
     AA=AX1.^2;
     VXX(k)=mean(AA(:));
 end
 R=0;
 for k=1:dim
    if VYY==0||VXX(k)==0
         R(k)=0
     end
     R(k)=VXY(k)/sqrt(VXX(k)*VYY);
 end
   function A=funAzhuan(X)
%XΪM*1����
[m dim]=size(X);
for i=1:m
     for j=1:m
         a(i,j)=abs(X(i,1)-X(j,1));
     end
 end
     ak=mean(a,2);
     al=mean(a,1);
     adian=mean(a(:));
for i=1:m
      for j=1:m
          A(i,j)=a(i,j)-ak(i,1)-al(1,j)+adian;
      end
end