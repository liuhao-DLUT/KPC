function error=NMAE(YX,Yreal,X)
%% Calculate NMAE error
    [N dim]=size(YX);
    for i=1:N
       ERR(i)=max(abs((Yreal(i,1)-YX(i,1))/Yreal(i,1)));
    end
    error=max(ERR);
end