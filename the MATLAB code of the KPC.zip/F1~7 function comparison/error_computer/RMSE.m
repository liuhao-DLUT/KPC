function error=RMSE(YX,Yreal,X)
%% Calculate RMSE error
    [n,m]=size(X);
    A=sqrt(sum((YX-Yreal).^2)/n);
    B=sum(Yreal)/n;
    error=100*A/B;
end
