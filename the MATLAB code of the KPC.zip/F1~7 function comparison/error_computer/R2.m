function error=R2(YX,Yreal,X)
%% Calculate R2 error
    [n,m]=size(X);
    a=(Yreal-YX).^2; b=sum(Yreal.^2);b1=(sum(Yreal(:)))^2;
    A=sum(a(:));B=b-b1/n;
    error=1-A/B;
end

