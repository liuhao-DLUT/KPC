clear all;close all;clc;warning off;
% 单变量的校准-工程算例  工况1
%% 参数输入
times=50;
circl=0;
while circl<times
circl=circl+1
dim_x=2;dim_t=1;                                                           
X=[2 8;2 8];T=[0 3];                             
t_intial=1.*ones(1,dim_t);        
Num_m1=300;Num_e1=4;Num_ce1=121;sigma_obs1=3;t_intial1=1.*ones(1,dim_t);  
Num_m2=100;Num_e2=4;Num_ce2=121;sigma_obs2=3;t_intial2=1.*ones(1,dim_t);
%% 集合汇总
for i=1:1
    j=i;
    Set_Nm{i}=eval(['Num_m',num2str(j)]);
    Set_Ne{i}=eval(['Num_e',num2str(j)]);
    Set_Nce{i}=eval(['Num_ce',num2str(j)]);
    Set_sigma_obs{i}=eval(['sigma_obs',num2str(j)]);
    Set_t_intial{i}=eval(['t_intial',num2str(i)]);
end
%% 数据导入
file_address=['N:\MDIC_ABQ\MDIC_calibiration\输入数据'];
XYm_frq=xlsread([file_address,'\1-Frq_XYm.xls']);                           % fre_ye_9  1-Frq_XYm
XYe_frq=xlsread([file_address,'\1-Frq_XYe.xls']);
XYce_frq=xlsread([file_address,'\1-Frq_XYce.xls']);
XYm_F=xlsread([file_address,'\2-F_XYm.xls']);
XYe_F=xlsread([file_address,'\2-F_XYe.xls']);
XYce_F=xlsread([file_address,'\2-F_XYce.xls']);
Xm_frq=XYm_frq(:,1:3);Ym_frq=XYm_frq(:,5);
Xe_frq=XYe_frq(:,1:2);Ye_frq=XYe_frq(:,4);t_real=1.7;
Xce_frq=XYce_frq(:,1:2);Yce_frq=XYce_frq(:,4);
Xm_F=XYm_F(:,1:3);Ym_F=XYm_F(:,4)./1000;
Xe_F=XYe_F(:,1:2);Ye_F=XYe_F(:,3)./1000;
Xce_F=XYce_F(:,1:2);Yce_F=XYce_F(:,3)./1000;
% 不确定性
for i=1:1
    Ye_F=normrnd(Ye_F,sigma_obs1);
    Ye_frq=normrnd(Ye_frq,sigma_obs2);
end
%%  数据整理
% 工况1-基频计算数据集
Set_Sm{1}=Xm_frq.*([X(:,2)',T(:,2)']-[X(:,1)',T(:,1)'])+[X(:,1)',T(:,1)'];
Set_Ym{1}=Ym_frq;
Set_Se{1}= Xe_frq.*(X(:,2)'-X(:,1)')+X(:,1)';
Set_Ye{1}= Ye_frq;
Set_X_ce{1}= Xce_frq.*(X(:,2)'-X(:,1)')+X(:,1)';
Set_Y_ce{1}= Yce_frq;
% 工况2-极限承载计算数据集
% Set_Sm{2}=Xm_F.*([X(:,2)',T(:,2)']-[X(:,1)',T(:,1)'])+[X(:,1)',T(:,1)'];
% Set_Ym{2}=Ym_F;
% Set_Se{2}= Xe_F.*(X(:,2)'-X(:,1)')+X(:,1)';
% Set_Ye{2}= Ye_F;
% Set_X_ce{2}= Xce_F.*(X(:,2)'-X(:,1)')+X(:,1)';
% Set_Y_ce{2}= Yce_F;

%% 多工况修正

%% 多目标OBC-----------------------------------------------------------------------------------
% step1:构建仿真代理模型
for k=1:size(Set_Se,2)
    theta0_M=1.*ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
    [Set_model{k},~]=dacefit(Set_Sm{k},Set_Ym{k}, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);
    [Y_M_predictor{k},s_m]=predictor([Set_Se{k},Set_t_intial{k}.*ones(Set_Ne{k},dim_t)],Set_model{k});
end
% step2：优化校准参数
t_ro_obj=@(t)OBC_calibration(t,Set_model,Set_Se,Set_Sm,Set_Ye);
[parameter_t,MLE_GP]= ga(t_ro_obj,dim_t,[],[],[],[],[T(:,1)'],[T(:,2)']);
parameter_t
% tt=(T(:,1)':0.01:T(:,2)')';
% for i=1:size(tt)
%     MOBC(i)=t_ro_obj(tt(i));
% end
% figure(1)
% plot(tt,MOBC)
% step4：预测
for k=1:size(Set_Se,2)
    [Y_M{k},~]=predictor([Set_X_ce{k},parameter_t.*ones(Set_Nce{k},dim_t)],Set_model{k});
    [Y_M_predictor{k},s_m]=predictor([Set_Se{k},parameter_t.*ones(Set_Ne{k},dim_t)],Set_model{k}); 
    theta0_E=10.*ones(1,dim_x);lob_E=1e-8.*ones(1,dim_x);up_E=100.*ones(1,dim_x);
    [model_discrepancy{k},~]=dacefit(Set_Se{k}, Set_Ye{k}-Y_M_predictor{k}, @regpoly0, @corrgauss, theta0_E,lob_E,up_E);
    [Y_discrepancy{k},~]=predictor(Set_X_ce{k},model_discrepancy{k});
    Y_predictor{k}=Y_M{k}+Y_discrepancy{k};
    R2(k)=ERRORr2(Y_predictor{k},Set_Y_ce{k},Set_X_ce{k});
    RMSE(k)=ERRORrmse(Y_predictor{k},Set_Y_ce{k},Set_X_ce{k});
end
name=['N:\MDIC_ABQ\MDIC_calibiration\数据-OBC\MOBC-1\',num2str(circl),'次预测结果'];
save(name, 'Y_predictor', 'Y_M','Y_discrepancy');
Athetat(circl,1)=parameter_t;
% R2 
ARMSEt(circl,:)=RMSE;
AR2t(circl,:)=R2;
end
save('N:\MDIC_ABQ\MDIC_calibiration\数据-OBC\OBC_1.mat')