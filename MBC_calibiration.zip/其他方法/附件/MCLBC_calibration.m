function  MDIC=MCLBC_calibration(t,Set_Se,Set_Ye,Set_Ne,Set_model)
    %% ��Ȩϵ��
    [N dim_t]=size(t);
    for k=1:size(Set_Se,2)
        [y,smxe]=predictor([Set_Se{k},t*ones(Set_Ne{k},dim_t)],Set_model{k});
        smxe=sqrt(smxe);
        s(k)=1/Set_Ne{k}*sum(smxe./(max(y)-min(y)));
        DIC(k)=MDIC_XG(Set_Ye{k},y);
    end
    if size(Set_Se,2)==1
        w(1,1)=1;
    else
        for i=1:size(Set_Se,2)
            w1=0.5*Set_Ne{i}/sum(cell2mat(Set_Ne));
            w2=0.5/(size(Set_Se,2)-1)*(1-s(i)/sum(s));
            w(1,i)=w1+w2; 
        end
    end
    %% ��������MDIC
    MDIC=1;
    for i=1:size(Set_Se,2)
         MDIC=DIC(i).^w(1,i).*MDIC;
    end
    MDIC=-MDIC;
end