function LnLe=MLE_LE(parameter_ro,Sm,Se,Ye,model_M,sigma_obs,calibration_t)
% The likelihood function of the discrepancy term
% Parameter to be estimated:
% ro:Scale factor
% theta_discrepancy:the hyperparameters of discrepancy term surrogate model
% sigma_discrepancy:the model variance of discrepancy term surrogate model
%% Parameter transmit
[~,dimXT]=size(Sm);[Num_E,dimX]=size(Se);dimT=dimXT-dimX;                  % Dimensional information
ro=parameter_ro(1);sig_E=parameter_ro(2);theta=parameter_ro(3:end);                                         % Parameter to be estimated
%% Calculating covariance matrix 
sig_M=model_M.sigma2;
S=[Se,calibration_t.*ones(Num_E,dimT)];                                    % Design variables and calibrated parameters of corresponding experiment
Vmm=R_correlation(Sm,Sm,model_M.theta);                            % Calculate the front M*M matrix of the covariance matrix, denoted as Vmm
Vmn=R_correlation(Sm,S,model_M.theta);                             % Calculate the M*N matrix of the covariance matrix, denoted as Vmn
Vnm=Vmn';                                                                  % The matrix Vnm is the transpose of Vmn
Vnn=R_correlation(S,S,model_M.theta);                              % Calculate the final N*N matrix of the covariance matrix, denoted as Vnn
V2c=Vnn-Vnm/Vmm*Vmn;                                                       % The Correlation matrix of the simulation model
ro2C=ro^2.*sig_M.*V2c;                                                                                                                                          
V_discrepancy=sig_E.*R_correlation(Se,Se,theta);                           % The covariance matrix of the discrepancy term
Ve  =ro2C+V_discrepancy+sigma_obs.*eye(Num_E);                             % Total covariance matrix
%% �ź�����W��
H2D2=ones(Num_E,1);
W2=1/(H2D2'/Ve*H2D2);
%% �ź�����beta��
Y_M_predictor=predictor(S,model_M);
beta2=W2*H2D2'/Ve*(Ye-ro.*Y_M_predictor);
%% ���Ƴ�������log�����Ȼ
Z_n=Ye-ro.*Y_M_predictor-H2D2*beta2;
LnLe=log(det(Ve))-log(det(W2))+Z_n'*(Ve^-1)*Z_n;
end