function sum_d=OBC_calibration(t,model_M,Se,Sm,Ye)
[Num dim]=size(Se);
calibration_t=t;
for i=1:Num
    [Num_M,dimXT]=size(Sm{i});
    [Num_E,dimX]=size(Se{i});
    dimT=dimXT-dimX;
    ro=1;
    S=[Se{i},calibration_t.*ones(Num_E,dimT)];
    Y_predictor=predictor(S,model_M{i});
    %Manhattan distance
    d(i)=sum(abs(Ye{i}-ro.*Y_predictor));
end
sum_d=sum(d);
end