%% calibration frame
clear all;clc;close all;warning('off');
%% 1、parameter setting
No=3;
dim_x=2;dim_t=1;                                                           % Dimensions of design variables x and calibration variables t
X=[0 1;0 1];T=[0 1];                                                           % Range of parameters for design variables and calibration variables
t_intial=0.5.*ones(1,dim_t);                                                 % Calibration parameter initial value
Num_m=50;Num_e=9;Num_test=100;                                                          % Simulation model and true test sample points
sigma_obs=50;                                                             % The variance of the Gaussian distribution,The mean is Ye
%% 2、sample input
% Parameter meaning: 
% Ye:Experimental observations   Se:The design variable corresponding to the experimental observation
% Ym:Simulation result           Sm:Design variables and calibration parameters corresponding to the simulation model
SYM=xlsread('G:\matlab\У׼�㷨\#paper��KOH_ABC\��0227_Section4.2\���ݴ洢\SYm_sample.xls');
Sm=SYM(:,1:end-1);Ym=SYM(:,end);
SYE=xlsread('G:\matlab\У׼�㷨\#paper��KOH_ABC\��0227_Section4.2\���ݴ洢\SYe_sample.xls');
Se=SYE(:,1:end-1);Ye=SYE(:,end);
SYE_test=xlsread('G:\matlab\У׼�㷨\#paper��KOH_ABC\��0227_Section4.2\���ݴ洢\SYe_test_sample.xls');
X_ce=SYE_test(:,1:end-1);Y_ce=SYE_test(:,end);
% %% #1、DBC-MLE-Calibration
% % Computational Model GP-----------------------------------------------------------------------------------
% theta0_M=1.*ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
% [model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);
% % Bayesian calibration-------------------------------------------------------------------------------------
% likelihood=@(t)fun_likelihood(Ye,Se,t,sigma_obs,model_M);
% post =@(t) likelihood (t) * prior(t,T(1,1),T(1,2));
% MLE=@(t) likelihood (t) * prior(t,T(1,1),T(1,2))*(-1);
% [DBC_MLE_t,MLE_max]=ga(MLE,1,[],[],[],[],T(:,1),T(:,2));
% % predictions----------------------------------------------------------------------------------------------
% S_ce=[X_ce,DBC_MLE_t.*ones(Num_test,1)];
% Y_ce_MLE=predictor(S_ce,model_M);
% DBC_MLE_R2=ERRORr2(Y_ce_MLE,Y_ce,X_ce);
% DBC_MLE_RMSE=ERRORrmse(Y_ce_MLE,Y_ce,X_ce);
% % Drawing and data storage---------------------------------------------------------------------------------
% t_drw=(T(:,1)':0.001:T(:,2)')';
% prob = ones(length(t_drw), 1);
% for i = 1:1:length(t_drw)
%     prob(i) = post(t_drw(i));
% end
% prob = prob / trapz(t_drw, prob);
% % the figure of posteriori distribution 
% t_MEL=t_drw*40000+50000;
% draw_DBC_MLE=[t_MEL,prob];
% figure(101)
% plot(t_MEL, prob);
% % the figure of predictions
% a=reshape(X_ce(:,1),10,10);
% b=a';
% c=reshape(Y_ce,10,10);
% % real physical processes
% figure(102)
% a=a*40+30;b=b*4+3;
% mesh(a,b,c)
% hold on
% % real physics predictions
% Y_r=reshape(Y_ce_MLE,10,10);
% mesh(a,b,Y_r)
% hold off
% % the figure of predictions absolute error
% figure(103)
% Y_absolute_error_MLE=abs(c-Y_r);
% mesh(a,b,Y_absolute_error_MLE)
% % Data Collection
% xx_a=X_ce(:,1)*40+30;xx_b=X_ce(:,2)*4+3;
% xx_DBC_MLE=[xx_a,xx_b,Y_ce,abs(Y_ce-Y_ce_MLE)];
% %% #2、DBC-ABC-Calibration
% % Computational Model GP-----------------------------------------------------------------------------------
% theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
% [model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);
% % DBC-ABC calibration--------------------------------------------------------------------------------------
% N=1E5;tolerance=6;                                                         % Sampling number and tolerance of ABC
% T_gather=[];t=[];                                                          % The sample set that satisfies the tolerance requirement
% for i=1:N
%     Y_obs=Ye;
%     t(i)=rand(1)*(T(:,2)'-T(:,1)')+T(:,1)';                                   
%     Y_sim=predictor([Se,t(i).*ones(Num_e,1)],model_M);                     % Under the current calibration parameters t, the simulation response corresponding to the test observation value
%     d(i)=distance_manhattan(Y_obs,Y_sim);           
% end
% distance_sort=[d',t'];[~,idx]=sort(distance_sort(:,1));distance_sort=distance_sort(idx,:);
% T_gather=distance_sort(1:N/1000,2); 
% [M N]=size(T_gather);
% [f_ABC,t_idx]=ksdensity(T_gather,'Bandwidth',0.1);              % Get a probability density estimate
% DBC_ABC_t=t_idx(find(f_ABC==max(f_ABC)));                                  % Get the calibration parameters
% % predictions---------------------------------------------------------------------------------------------
% S_ce=[X_ce,DBC_ABC_t.*ones(Num_test,1)];
% Y_ce_ABC=predictor(S_ce,model_M);
% DBC_ABC_R2=ERRORr2(Y_ce_ABC,Y_ce,X_ce);
% DBC_ABC_RMSE=ERRORrmse(Y_ce_ABC,Y_ce,X_ce);
% % Drawing and data storage-------------------------------------------------------------------------------
% % the figure of posteriori distribution 
% t_ABC=t_idx*40000+50000;
% draw_DBC_ABC=[t_ABC',f_ABC'];
% figure(201)
% plot(t_ABC,f_ABC);
% % the figure of predictions
% a=reshape(X_ce(:,1),10,10);
% b=a';
% c=reshape(Y_ce,10,10);
% % real physical processes
% figure(202)
% a=a*40+30;b=b*4+3;
% mesh(a,b,c)
% hold on
% % real physics predictions
% Y_r=reshape(Y_ce_ABC,10,10);
% mesh(a,b,Y_r)
% hold off
% % the figure of predictions absolute error
% figure(203)
% Y_absolute_error_ABC=abs(c-Y_r);
% mesh(a,b,Y_absolute_error_ABC)
% % Data Collection
% xx_a=X_ce(:,1)*40+30;xx_b=X_ce(:,2)*4+3;
% xx_DBC_ABC=[xx_a,xx_b,Y_ce,abs(Y_ce-Y_ce_ABC)];
% %% #3、KOH-Calibration
% % Computational Model GP-----------------------------------------------------------------------------------
% theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
% [model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);    
% parameter_GP1=struct('theta_M',model_M.theta,'sig_M',model_M.sigma2,'beta1',model_M.beta); 
% % discrepancy function GP----------------------------------------------------------------------------------
% [Y_M_predictor,s_m]=predictor([Se,t_intial.*ones(Num_e,dim_t)],model_M); 
% MLE_GP2_obj=@(t)MLE_discrepancy(t,Sm,Se,Ye,Y_M_predictor,parameter_GP1,model_M,sigma_obs,t_intial); 
% [parameter_E,MLE_GP]= ga(MLE_GP2_obj,2+dim_x,[],[],[],[],[0,1e-5,1e-5*ones(1,dim_x)],[10,1^10,60*ones(1,dim_x)]);
% ro=parameter_E(1);ro_KOH=ro;                                                        
% sigma_discrepancy=parameter_E(2);                                          
% theta_discrepancy=parameter_E(3:end);                                      
% parameter_GP2=struct('theta_E',theta_discrepancy,'ro',ro,'sigma_obs',sigma_obs,'sig_E',sigma_discrepancy);
% % calibrations---------------------------------------------------------------------------------------------
% calib_obj=@(calibration_t)MLE_calibration(calibration_t,Sm,Se,Ym,Ye,parameter_GP1,parameter_GP2,model_M);  
% [KOH_t,MAX_LM]= ga(calib_obj,dim_t,[],[],[],[],T(:,1)',T(:,2)');
% [Y_M_predictor,s_m]=predictor([Se,KOH_t.*ones(Num_e,dim_t)],model_M); 
% [model_discrepancy,~]=dacefit(Se, Ye-ro.*Y_M_predictor, @regpoly0, @corrgauss,theta_discrepancy);
% % predictions---------------------------------------------------------------------------------------------
% S_ce=[X_ce,KOH_t.*ones(Num_test,1)];
% Ym_ce_KOH=predictor(S_ce,model_M);
% [Y_discrepancy,~]=predictor(X_ce,model_discrepancy);
% Y_ce_KOH=Ym_ce_KOH.*ro+Y_discrepancy;
% KOH_R2=ERRORr2(Y_ce_KOH,Y_ce,X_ce);
% KOH_RMSE=ERRORrmse(Y_ce_KOH,Y_ce,X_ce);
% % Drawing and data storage---------------------------------------------------------------------------------
% t_drw=(T(:,1)':0.001:T(:,2)')';
% global Phi_max Phi_min
% Phi_min=T(:,1);Phi_max=T(:,2);
% prob = [];
% for i = 1:1:length(t_drw)
%     prob(i) =-calib_obj(t_drw(i))*prior(t_drw(i),T(:,1),T(:,2));
% end
% prob = prob / trapz(t_drw, prob);
% % the figure of posteriori distribution 
% t_KOH=t_drw*40000+50000;
% draw_KOH=[t_KOH,prob'];
% figure(301)
% plot(t_KOH, prob);
% % the figure of predictions
% a=reshape(X_ce(:,1),10,10);
% b=a';
% c=reshape(Y_ce,10,10);
% % real physical processes
% figure(302)
% a=a*40+30;b=b*4+3;
% mesh(a,b,c)
% hold on
% % real physics predictions
% Y_r=reshape(Y_ce_KOH,10,10);
% mesh(a,b,Y_r)
% hold off
% % the figure of predictions absolute error
% figure(303)
% Y_absolute_error_KOH=abs(c-Y_r);
% mesh(a,b,Y_absolute_error_KOH)
% % Data Collection
% xx_a=X_ce(:,1)*40+30;xx_b=X_ce(:,2)*4+3;
% xx_KOH=[xx_a,xx_b,Y_ce,abs(Y_ce-Y_ce_KOH)];
%% #4、OBC-Calibration
% Computational Model GP-----------------------------------------------------------------------------------
theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
[model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);   
[Y_M_predictor,s_m]=predictor([Se,t_intial.*ones(Num_e,dim_t)],model_M); 
% calibrations---------------------------------------------------------------------------------------------
t_ro_obj=@(t)OBC_calibration(t,model_M,Se,Sm,Ye);
[parameter_t_ro,MLE_GP]= ga(t_ro_obj,1+dim_t,[],[],[],[],[1,T(:,1)'],[1,T(:,2)']);
ro_OBC=parameter_t_ro(:,1)                                                   % the scale factor (ro)
OBC_t=parameter_t_ro(:,2:end);  
% discrepancy function GP----------------------------------------------------------------------------------
[Y_M_predictor,s_m]=predictor([Se,OBC_t.*ones(Num_e,dim_t)],model_M); 
theta0_E=ones(1,dim_x);lob_E=1e-8.*ones(1,dim_x);up_E=100.*ones(1,dim_x);
[model_discrepancy,~]=dacefit(Se, Ye-ro_OBC.*Y_M_predictor, @regpoly0, @corrgauss,theta0_E,lob_E,up_E);
% predictions---------------------------------------------------------------------------------------------
[Y_M,~]=predictor([X_ce,OBC_t.*ones(Num_test,dim_t)],model_M);       % The simulated predicted value of the test set
[Y_discrepancy,~]=predictor(X_ce,model_discrepancy);                     % The predicted value of the deviation term
Y_ce_OBC=Y_M.*ro_OBC+Y_discrepancy;                                         % The predicted value of the experiment
OBC_R2=ERRORr2(Y_ce_OBC,Y_ce,X_ce);                                      % r2
OBC_RMSE=ERRORrmse(Y_ce_OBC,Y_ce,X_ce);                                  % Mean square error analysis
% Drawing and data storage---------------------------------------------------------------------------------
MLE=@(t)OBC_MLE(t,model_M,model_discrepancy,Se,Ye,ro_OBC,sigma_obs) * prior(t,T(1,1),T(1,2));
t_drw=(T(:,1)':0.001:T(:,2)')';
prob = [];
for i = 1:length(t_drw)
    prob(i) = MLE(t_drw(i));
end
prob = prob / trapz(t_drw, prob);
% the figure of posteriori distribution 
t_OBC=t_drw*40000+50000;
draw_OBC=[t_OBC,prob'];
figure(401)
plot(t_OBC, prob);
% the figure of predictions
a=reshape(X_ce(:,1),10,10);
b=a';
c=reshape(Y_ce,10,10);
% real physical processes
figure(402)
a=a*40+30;b=b*4+3;
mesh(a,b,c)
hold on
% real physics predictions
Y_r=reshape(Y_ce_OBC,10,10);
mesh(a,b,Y_r)
hold off
% the figure of predictions absolute error
figure(403)
Y_absolute_error_OBC=abs(c-Y_r);
mesh(a,b,Y_absolute_error_OBC)
% Data Collection
xx_a=X_ce(:,1)*40+30;xx_b=X_ce(:,2)*4+3;
xx_OBC=[xx_a,xx_b,Y_ce,abs(Y_ce-Y_ce_OBC)];
% %% #5、CLC-Calibration
% %% Module 1: Build the surrogate model of the simulation model
% theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
% % The initial value of the hyperparameter of the surrogate model and its upper and lower limits
% [model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);    % Build the Kriging surrogate model of the simulation model
% parameter_GP1=struct('theta_M',model_M.theta,'sig_M',model_M.sigma2);      % Summary of parameters of the simulation surrogate model
% %% Module 2: Approximate Bayesian parameter calibration (t) based on a new measure
% % The ABC algorithm is detailed in the paper "Approximate Bayesian
% % Computational methodsfor the inference of unknown parameters". Here a
% % Rejection ABC method is taken.
% N=1E5;tolerance=1E-3;                                                     % Sampling number and tolerance of ABC
% t=[];
% T_gather=[];                                                                % The sample set that satisfies the tolerance requirement
% for i=1:N
%     Y_obs=Ye;
%     t(i)=rand(1)*(T(:,2)'-T(:,1)')+T(:,1)';                                   
%     % A sample point is extracted based on the prior distribution type of calibration parameters
%     % the algorithm generally assumes uniform distribution.
%     Y_sim=predictor([Se,t(i).*ones(Num_e,1)],model_M);                     % Under the current calibration parameters t, the simulation response corresponding to the test observation value
%     d(i)=distance_DIC(Y_obs,Y_sim);                                    % A double metric based on distance correlation and complementary similarity
% end
% distance_sort=[d',t'];[~,idx]=sort(distance_sort(:,1));distance_sort=distance_sort(idx,:);
% % Ordering the measure of approximate Bayesian computation from smallest to largest
% T_gather=distance_sort(1:N/1000,2);                                         % Taking the first n=100 measure to satisfy the requirement
% [f_CLC,t_idx]=ksdensity(T_gather,'Bandwidth',sigma_obs/1000);                         % Get a probability density estimate
% CLC_t=t_idx(find(f_CLC==max(f_CLC)));                               % Get the calibration parameters 
% %% Module 3: Estimating Scale factor (ro) and discrepancy term surrogate model based on maximum likelihood function
% % This module estimates Scale factor (ro) and discrepancy term surrogate model hyperparameters
% % Parameter meaning: 
% % ro:Scale factor
% % theta_discrepancy:the hyperparameters of discrepancy term surrogate model
% % sigma_discrepancy:the model variance of discrepancy term surrogate model
% [Y_M_predictor,s_m]=predictor([Se,CLC_t.*ones(Num_e,dim_t)],model_M); 
% % Simulation prediction results under calibration parameters
% MLE_GP2_obj=@(t)MLE_discrepancy(t,Sm,Se,Ye,Y_M_predictor,parameter_GP1,model_M,sigma_obs,CLC_t); 
% % likelihood function
% [parameter_E,~]= ga(MLE_GP2_obj,2+dim_x,[],[],[],[],[0,1e-5,1e-5*ones(1,dim_x)],[3,10^10,60*ones(1,dim_x)]);
% % The maximum likelihood function is optimized to obtain the scale factor and the hyperparameters of discrepancy term surrogates model
% ro=parameter_E(1);ro_CLC=ro;                                                          % the scale factor (ro)
% sigma_discrepancy=parameter_E(2);                                          % sigma_discrepancy
% theta_discrepancy=parameter_E(3:end);                                      % theta_discrepancy
% [model_discrepancy,~]=dacefit(Se, Ye-ro.*Y_M_predictor, @regpoly0, @corrgauss,theta_discrepancy);
% % Construct the discrepancy term surrogate model
% %% Module 4: Prediction                                                  % Calculating the true response of the test set
% [Y_M,~]=predictor([X_ce,CLC_t.*ones(Num_test,dim_t)],model_M);             % The simulated predicted value of the test set
% [Y_discrepancy,~]=predictor(X_ce,model_discrepancy);                       % The predicted value of the deviation term
% Y_ce_CLC=Y_M.*ro+Y_discrepancy;                                            % The predicted value of the experiment
% CLC_R2=ERRORr2(Y_ce_CLC,Y_ce,X_ce);                                        % r2
% CLC_RMSE=ERRORrmse(Y_ce_CLC,Y_ce,X_ce);                                    % Mean square error analysis
% % Drawing and data storage-------------------------------------------------------------------------------
% % the figure of posteriori distribution 
% t_CLC=t_idx*40000+50000;
% draw_CLC=[t_CLC',f_CLC'];
% figure(501)
% plot(t_CLC,f_CLC);
% % the figure of predictions
% a=reshape(X_ce(:,1),10,10);
% b=a';
% c=reshape(Y_ce,10,10);
% % real physical processes
% figure(502)
% a=a*40+30;b=b*4+3;
% mesh(a,b,c)
% hold on
% % real physics predictions
% Y_r=reshape(Y_ce_CLC,10,10);
% mesh(a,b,Y_r)
% hold off
% % the figure of predictions absolute error
% figure(503)
% Y_absolute_error_CLC=abs(c-Y_r);
% mesh(a,b,Y_absolute_error_CLC)
% % Data Collection
% xx_a=X_ce(:,1)*40+30;xx_b=X_ce(:,2)*4+3;
% xx_CLC=[xx_a,xx_b,Y_ce,abs(Y_ce-Y_ce_CLC)];
% %%------------------------------------------------------------------------------------------------
% t_calibration=[DBC_MLE_t,DBC_ABC_t,KOH_t,OBC_t,CLC_t,ro_KOH,ro_OBC,ro_CLC];
% output=[DBC_MLE_RMSE,DBC_ABC_RMSE,KOH_RMSE,OBC_RMSE,CLC_RMSE];
OBC_calibration_out=[OBC_t,OBC_RMSE];
% Summary of calibration results
outwork=['G:\matlab\У׼�㷨\#paper��KOH_ABC\��0227_Section4.2\���ݴ洢\��OBC\No',num2str(No),'\'];
xlswrite([outwork,'OBCУ׼���.xls'],OBC_calibration_out);   
% Summary of the posteriori distributions
% OBC
xlswrite([outwork,'2-4OBC��ͼ����.xls'],draw_OBC);
% Summary of predictions and errors 
% OBC
xlswrite([outwork,'1-4OBC_����ֲ�.xls'],xx_OBC);  










