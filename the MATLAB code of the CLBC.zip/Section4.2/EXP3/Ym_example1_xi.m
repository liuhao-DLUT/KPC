function   F=Ym_example1_xi(x)
    % Simulation analysis model, single stage stiffened shell buckling characteristic value
    % The design variables are the orthogonal thickness and height of the bar
    % The calibration variable is the elastic modulus of the material
%     x(:,1)=x(:,1)*10+5;x(:,2)=x(:,2)*20+10;
    x(:,1)=x(:,1)*40+30;x(:,2)=x(:,2)*4+3;
%     x(:,1)=10;x(:,2)=50;x(:,3)=x(:,3)*10+2;
    %% input parameter
    [Num dim]=size(x);
    out_path=['L:\matlab\paper_KOH_ABC\EXP1'];
    abaqus_path=['G:\SIMULIA\Commands'];
    fp1 = fopen([out_path,'\input_danji_xi.txt'],'wt'); 
    for i=1:dim
        fprintf(fp1,'%f**',x(i));
    end
    fclose(fp1);
    work_py=['call ',abaqus_path,'\abq2020 cae nogui=',out_path,'\danji_zhengzhizhengjiao_70.py'];
    fp3 = fopen([out_path,'\run.bat'],'wt'); 
    fprintf(fp3, '%s\n', work_py );
    fclose(fp3);  
    %% calculating
        system([out_path,'\run.bat']);
    %% output parameter
    Load_path=[out_path,'\result\FF_danji.txt'];
    F=textread(Load_path,'%s','delimiter','\n');
    F=str2num(F{1,1})/1E3
end