clear all;clc;close all;
% 算例1抽点
% 单级加筋算例   两个模型网格不同   模型1 mesh=10800   模型2 mesh=20550
%% 仿真模型 样本点个数100，设计参数2个，校准参数1个
N_m=50;
dim_x=2;dim_t=1;
Sm=lhsdesign(N_m,dim_x+dim_t);
for ii=1:N_m
    ii
    Ym(ii,1)=Ym_example1_cu(Sm(ii,:));
end
SYm=[Sm,Ym];
% figure(1)
% plot(Sm(:,3),Ym,'O')
xlswrite('SYm_mp.xls',SYm);
%% 精细模型 样本点个数10，设计参数2个
Se = gridsamp([0 0;1 1], 3);
[N_e dim]=size(Se);
% N_e=100;
% Se=lhsdesign(N_e,dim_x);
for ii=1:N_e
    ii
    Ye(ii,1)=Ym_example1_xi(Se(ii,:));
end
% figure(2)
% plot(Se(:,2),Ye,'O') 
SYe=[Se,Ye(1:N_e,:)];
xlswrite('SYe_50.xls',SYe);
fprintf("---------------------------------完成-----------------------------------")