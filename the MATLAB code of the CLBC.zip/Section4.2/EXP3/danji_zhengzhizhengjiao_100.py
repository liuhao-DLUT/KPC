#!/usr/bin/env python
#coding=utf-8

from abaqus import*
from part import*
from material import*
from section import*
from assembly import*
from step import*
from interaction import*
from load import*
from mesh import*
from job import*
from sketch import*
from visualization import*
from string import*
from math import*
import section
import regionToolset
import displayGroupMdbToolset as dgm
import part
import material
import assembly
import step
import interaction
import load
import mesh
import job
import sketch
import visualization
import xyPlot
import displayGroupOdbToolset as dgo
import connectorBehavior
import os
import displayGroupOdbToolset as dgo
import __main__
global pi

import os
cwd = os.getcwd()
path_result=cwd+'/result'
import os  ##设置路径
os.chdir(path_result)

pi=acos(-1.0)

# list0=[]
# with open(‘input.txt’,'t') as f0:
	# for i in f0:
		# tmp=i.split()
		# list0.append(tmp[0])

# D=eval(list0[0])
# NN=int(eval(list0[0]))
input_file=cwd+'/input_danji_cu.txt'
f = open(input_file, 'r')
sourceInLines = f.readlines()          #按行读出文件内容
f.close()
variable = []
for line in sourceInLines:
    temp1 = line.strip('\n')               #去掉每行最后的换行符'\n'
    temp2 = temp1.split('**')              #以','为标志，将每行分割成列表
    variable.append(temp2)  

print(variable)
for i in range (3):
    variable[0][i]=float(variable[0][i])

###################输入参数###########################################
###筒壳结构参数###设计变量
Skin_t=2				#蒙皮厚度
cellH=1000					####BS_A环向筋条的距离  
cellL=1010.0				####bs_C轴向筋条的距离
Stiffener_t1=variable[0][0]		##tr2竖筋条厚度！！！！和ANSYS中的命名1/2正好相反，看赋予的名字副属性
Stiffener_t2=variable[0][0]		##tr1横筋条厚度！！！！和ANSYS中的命名1/2正好相反，看赋予的名字副属性
Stiffener_h=variable[0][1]-Skin_t		#筋条高度



Height=5000.0							#筒壳高度
Radius=5000/2.0-0.5*Skin_t	#筒壳半径

###材料参数####
EE=variable[0][2]			#弹性模量
vv=0.3					#泊松比
densitys=2.8e-09		#密度
sigemas=363.0			#屈服应力
UTS=434.0					#强度极限
nta=0.08					#延伸率


# pressure1=0.0						###MPa 内压值
# cal_time1=0.25				#内压加载时间



# MeshSize=min(cellH,cellL)/4				#网格大小
MeshSize=100
###	parameter	####
### parameter ####
# if min(cellL,cellH) < 200.0 :
	# MeshSize=min(cellL,cellH)/4		####细化网格尺寸####
Meshsize=100

NumCpus=8 			### cpu运算核数 ######
Memory=40  			####计算内存大小###
############################################################################

######
CirCellNum1=2*pi*Radius/cellL##环向单胞数量
CirCellNum2=int(ceil(2*pi*Radius/(cellL)))-1##环向单胞向吓整数
cellL=cellL*CirCellNum1/CirCellNum2
CirCellNum=CirCellNum2

AxialCellNum1=Height/(cellH)
AxialCellNum2=int(ceil(Height/(cellH)))
cellH=cellH*AxialCellNum1/AxialCellNum2##调整后的单胞高度
AxialCellNum=AxialCellNum2##最终轴向单胞数量
Height=AxialCellNum*cellH
##### material ##################################################################
mdb.models['Model-1'].Material(name='AL2024')
mdb.models['Model-1'].materials['AL2024'].Density(table=((densitys, ), ))
mdb.models['Model-1'].materials['AL2024'].Elastic(table=((EE, vv), ))
# mdb.models['Model-1'].materials['AL2024'].Plastic(table=((sigemas, 0.0), (UTS, nta)))


##主级竖筋赋属性
mdb.models['Model-1'].HomogeneousShellSection(name='Stiffener1', preIntegrate=OFF, 
		material='AL2024', thicknessType=UNIFORM,	thickness=Stiffener_t1,	thicknessField='', 
		idealization=NO_IDEALIZATION,	poissonDefinition=DEFAULT, 
		thicknessModulus=None, temperature=GRADIENT, useDensity=OFF, 
		integrationRule=SIMPSON, numIntPts=5)
##
##横筋赋属性
mdb.models['Model-1'].HomogeneousShellSection(name='Stiffener2', preIntegrate=OFF, 
		material='AL2024', thicknessType=UNIFORM,	thickness=Stiffener_t2,	thicknessField='', 
		idealization=NO_IDEALIZATION,	poissonDefinition=DEFAULT, 
		thicknessModulus=None, temperature=GRADIENT,useDensity=OFF,	
		integrationRule=SIMPSON, numIntPts=5)
##
##蒙皮赋予属性
mdb.models['Model-1'].HomogeneousShellSection(name='Skin', preIntegrate=OFF, 
		material='AL2024', thicknessType=UNIFORM,	thickness=Skin_t,	thicknessField='', 
		idealization=NO_IDEALIZATION,	poissonDefinition=DEFAULT, 
		thicknessModulus=None, temperature=GRADIENT, useDensity=OFF, 
		integrationRule=SIMPSON, numIntPts=5)

###Grid 2 #########################蒙皮建立
######################################
### GridSkin ###
partname='GridSkin'
facename='SkinFace'
x1=Radius
y1=0.0
x2=x1

angle=360.0*cellL/(2.0*pi*Radius)
y2=cellH


s = mdb.models['Model-1'].ConstrainedSketch(name='__profile__', 
  sheetSize=Meshsize)
g, v, d, c = s.geometry, s.vertices, s.dimensions, s.constraints
s.setPrimaryObject(option=STANDALONE)
s.ConstructionLine(point1=(0.0, -100.0), point2=(0.0, 100.0))
s.FixedConstraint(entity=g[2])
s.Line(point1=(x1, y1), point2=(x2, y2))
s.VerticalConstraint(entity=g[3], addUndoState=False)
p = mdb.models['Model-1'].Part(name=partname, dimensionality=THREE_D, 
  type=DEFORMABLE_BODY)
p = mdb.models['Model-1'].parts[partname]
p.BaseShellRevolve(sketch=s, angle=angle, flipRevolveDirection=OFF)
s.unsetPrimaryObject()
p = mdb.models['Model-1'].parts[partname]
session.viewports['Viewport: 1'].setValues(displayedObject=p)
del mdb.models['Model-1'].sketches['__profile__']
##### section ####################################
p = mdb.models['Model-1'].parts[partname]
faces = p.faces
region = regionToolset.Region(faces=faces)
p.SectionAssignment(region=region, sectionName='Skin', offset=0.0, 
  offsetType=MIDDLE_SURFACE, offsetField='', 
  thicknessAssignment=FROM_SECTION)

mdb.models['Model-1'].parts[partname].Set(faces=faces, name=facename)

#####Ringer	#############################横向筋条建立
partname='hengxiang'
facename='hengxiangface'
x1=Radius
y1=0.0
x2=x1-Stiffener_h
y2=y1
s1 = mdb.models['Model-1'].ConstrainedSketch(name='__profile__', 
	sheetSize=Meshsize)
g, v,	d, c = s1.geometry,	s1.vertices, s1.dimensions,	s1.constraints
s1.setPrimaryObject(option=STANDALONE)
s1.ConstructionLine(point1=(0.0, -100.0),	point2=(0.0, 100.0))
s1.FixedConstraint(entity=g[2])
s1.Line(point1=(x1,	y1), point2=(x2, y2))
s1.HorizontalConstraint(entity=g[3], addUndoState=False)
p	=	mdb.models['Model-1'].Part(name=partname,	dimensionality=THREE_D,	
	type=DEFORMABLE_BODY)
p	=	mdb.models['Model-1'].parts[partname]
p.BaseShellRevolve(sketch=s1,	angle=angle, flipRevolveDirection=OFF)
s1.unsetPrimaryObject()
p	=	mdb.models['Model-1'].parts[partname]
session.viewports['Viewport: 1'].setValues(displayedObject=p)
del	mdb.models['Model-1'].sketches['__profile__']

p	=	mdb.models['Model-1'].parts[partname]
faces	=	p.faces
mdb.models['Model-1'].parts[partname].Set(faces=faces, name=facename)

p	=	mdb.models['Model-1'].parts[partname]
faces	=	p.faces
region = regionToolset.Region(faces=faces)
p.SectionAssignment(region=region, sectionName='Stiffener2', offset=0.0, 
		offsetType=MIDDLE_SURFACE, offsetField='', 
		thicknessAssignment=FROM_SECTION)

##### Grid2Stringer #################################竖直直筋建立
partname='shuzhi'
facename='shuzhiFace'
x1=Radius
y1=0.0
x2=x1-Stiffener_h
y2=cellH
session.viewports['Viewport: 1'].setValues(displayedObject=None)
s1 = mdb.models['Model-1'].ConstrainedSketch(name='__profile__', 
  sheetSize=Meshsize)
g, v, d, c = s1.geometry, s1.vertices, s1.dimensions, s1.constraints
s1.setPrimaryObject(option=STANDALONE)
s1.rectangle(point1=(x1, y1), point2=(x2, y2))
p = mdb.models['Model-1'].Part(name=partname, dimensionality=THREE_D, 
  type=DEFORMABLE_BODY)
p = mdb.models['Model-1'].parts[partname]
p.BaseShell(sketch=s1)
s1.unsetPrimaryObject()
p = mdb.models['Model-1'].parts[partname]
session.viewports['Viewport: 1'].setValues(displayedObject=p)
del mdb.models['Model-1'].sketches['__profile__']
#section-Stiffener1######

p = mdb.models['Model-1'].parts[partname]
faces = p.faces
region = regionToolset.Region(faces=faces)
p.SectionAssignment(region=region, sectionName='Stiffener1', offset=0.0, 
  offsetType=MIDDLE_SURFACE, offsetField='', 
  thicknessAssignment=FROM_SECTION)
p = mdb.models['Model-1'].parts['shuzhi']
f = p.faces
faces = f.getSequenceFromMask(mask=('[#1 ]', ), )
p.Set(faces=faces, name='shuzhiFace')

#### Grid2 ##################
a = mdb.models['Model-1'].rootAssembly
a.DatumCsysByDefault(CARTESIAN)
p = mdb.models['Model-1'].parts['hengxiang']
a.Instance(name='hengxiang-1', part=p, dependent=ON)
p = mdb.models['Model-1'].parts['shuzhi']
a.Instance(name='shuzhi-1', part=p, dependent=ON)
p = mdb.models['Model-1'].parts['GridSkin']
a.Instance(name='GridSkin-2', part=p, dependent=ON)

##
###补全另一半###
a = mdb.models['Model-1'].rootAssembly
a.RadialInstancePattern(instanceList=('shuzhi-1', ), point=(0.0, 0.0, 
  0.0), axis=(0.0, -1.0, 0.0), number=2, totalAngle=angle)

a1 = mdb.models['Model-1'].rootAssembly
a1.LinearInstancePattern(instanceList=('hengxiang-1', ), direction1=(0.0, 1.0, 
    0.0), direction2=(0.0, 1.0, 0.0), number1=2, number2=1, spacing1=cellH, 
    spacing2=1.0)


##### section ####################################
a.InstanceFromBooleanMerge(name='Grid2s', instances=( 
  a.instances['hengxiang-1'], a.instances['shuzhi-1'], 
  a.instances['shuzhi-1-rad-2'], a.instances['hengxiang-1-lin-2-1'],), keepIntersections=ON, 
  originalInstances=SUPPRESS, domain=GEOMETRY)

#######set-Grid2s-side###################

angle_rad=cellL/Radius    #环向单胞的角度

p = mdb.models['Model-1'].parts['Grid2s']
edges = p.edges.findAt(((Radius-Stiffener_h/2,0.0,0.0),))+p.edges.findAt(((Radius-Stiffener_h/2,cellH,0.0),))\
+p.edges.findAt((((Radius-Stiffener_h/2)*cos(angle_rad),0.0,(Radius-Stiffener_h/2)*sin(angle_rad)),))+p.edges.findAt((((Radius-Stiffener_h/2)*cos(angle_rad),cellH,(Radius-Stiffener_h/2)*sin(angle_rad)),))
p.Set(edges=edges, name='Grid2s-side')


a.InstanceFromBooleanMerge(name='Grid2', instances=(a.instances['GridSkin-2'], 
  a.instances['Grid2s-1'], ), keepIntersections=ON, 
  originalInstances=SUPPRESS, domain=GEOMETRY)

##内压的表面设置
Surfacename='CylinderSurface'
p = mdb.models['Model-1'].parts['Grid2']
facelist=p.sets['SkinFace'].faces
mdb.models['Model-1'].parts['Grid2'].Surface(side2Faces=facelist, name=Surfacename)

partname='Grid2'
facename='MP_StringerFace0'
p = mdb.models['Model-1'].parts[partname]
faces = p.faces
mdb.models['Model-1'].parts[partname].Set(faces=faces, name=facename)


#######merge###################轴向循环单胞!!注意这样对于轴向一半的多一部分需要最后镜像掉
a	=	mdb.models['Model-1'].rootAssembly
a.RadialInstancePattern(instanceList=('Grid2-1',	), point=(0.0, 0.0,	0.0),	
	axis=(0.0, 1.0,	0.0),	number=CirCellNum,	totalAngle=-(CirCellNum-1)*angle)

##将上述单层进行合成一层并且形成一个大单胞
m=mdb.models['Model-1']##
r=m.rootAssembly
inslist=[]
for	key	in m.rootAssembly.instances.keys():
	if key.find('Grid2-1')!=-1:
		inslist.append(m.rootAssembly.instances[key])

r.InstanceFromBooleanMerge(name='huan-1',instances=
	inslist,keepIntersections=ON, originalInstances=DELETE)


##纵向合成
a	=	mdb.models['Model-1'].rootAssembly
a.LinearInstancePattern(instanceList=('huan-1-1',	), direction1=(0.0,	0.0, 
	0.0),	direction2=(0.0, 1.0,	0.0),	number1=1, number2=AxialCellNum,	spacing1=3000.0, 
	spacing2=cellH)

##将上述形成的单胞再次合成一个单胞
m=mdb.models['Model-1']
r=m.rootAssembly
inslist=[]
for	key	in m.rootAssembly.instances.keys():
	if key.find('huan-1')!=-1:
		inslist.append(m.rootAssembly.instances[key])

r.InstanceFromBooleanMerge(name='Cylinder11',instances=
	inslist,keepIntersections=ON, originalInstances=DELETE)

####进行材料偏置一下
mdb.models['Model-1'].parts['Cylinder11'].sectionAssignments[0].setValues(
    offsetType=BOTTOM_SURFACE, offsetField='', offset=0.0)






##底部命名
a	=	mdb.models['Model-1'].rootAssembly
partname='Cylinder11'
setname='CylinderBot'
HHcellh=0.0
ps = mdb.models['Model-1'].parts[partname]
tol=1.0e-6
edgelist=[]
sidenumber=int((ps.edges[-1].index+1))
sidenumber1=int((ps.edges[-1].index+1)/(AxialCellNum+1)*(AxialCellNum-1))
for	i	in range(sidenumber1,sidenumber):
		tmp=True
		for	j	in ps.edges[i].getVertices():
				pt=ps.vertices[j].pointOn
				value_z=pt[0][2]
				value_x=pt[0][0]
				value_y=pt[0][1]
				if value_y > HHcellh+tol :
					tmp=False			 
		if tmp==True:
			edgelist.append(ps.edges.findAt(ps.edges[i].pointOn))

mdb.models['Model-1'].parts[partname].Set(edges=edgelist,	name=setname)

##顶部命名
partname='Cylinder11'
setname='CylinderTop'
HHcellh=Height
ps = mdb.models['Model-1'].parts[partname]
tol=1.0e-6
edgelist=[]
sidenumber0=int((ps.edges[-1].index+1)/(AxialCellNum)*1.5)
for	i	in range(0,sidenumber0):
		tmp=True
		for	j	in ps.edges[i].getVertices():
				pt=ps.vertices[j].pointOn
				value_z=pt[0][2]
				value_x=pt[0][0]
				value_y=pt[0][1]
				if value_y < HHcellh-tol :
					tmp=False			 
		if tmp==True:
			edgelist.append(ps.edges.findAt(ps.edges[i].pointOn))

mdb.models['Model-1'].parts[partname].Set(edges=edgelist,	name=setname)
###### 耦合点建立	#############################################
a	=	mdb.models['Model-1'].rootAssembly
rp1=a.ReferencePoint(point=(0.0,cellH*AxialCellNum, 0.0))
##顶部进行耦合
a	=	mdb.models['Model-1'].rootAssembly
r1 = a.referencePoints
refPoints1=(r1[rp1.id], )
region1=regionToolset.Region(referencePoints=refPoints1)
a	=	mdb.models['Model-1'].rootAssembly
region2=a.instances['Cylinder11-1'].sets['CylinderTop']
mdb.models['Model-1'].Coupling(name='Constraint-1',	controlPoint=region1,	
		surface=region2, influenceRadius=WHOLE_SURFACE,	couplingType=KINEMATIC,	
		localCsys=None,	u1=ON, u2=ON,	u3=ON, ur1=ON, ur2=ON, ur3=ON)



###### mesh ################################################################
p = mdb.models['Model-1'].parts['Cylinder11']
p.seedPart(size=MeshSize, deviationFactor=0.1, minSizeFactor=0.1)

setlist =[]
for key in p.sets.keys():
    if key.find('-side')!=-1:
       setlist.append(key)

#######       
for setname in setlist:
    pickedgs=p.sets[setname].edges
    p.seedEdgeByNumber(edges=pickedgs,number=2,constraint=FINER)



Region=p.sets['hengxiangface'].faces
p.generateMesh(regions=Region)

Region=p.sets['shuzhiFace'].faces
p.generateMesh(regions=Region)

Region=p.sets['SkinFace'].faces
p.generateMesh(regions=Region)


##设置step，buckle算法
mdb.models['Model-1'].BuckleStep(name='Step-1', previous='Initial', numEigen=5, 
    eigensolver=LANCZOS, minEigen=0.0, blockSize=DEFAULT, maxBlocks=DEFAULT)
session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='Step-1')
##施加内压
# Surfacename='CylinderSurface'
# region = a.instances['Cylinder11-1'].surfaces[Surfacename]
# # mdb.models['Model-1'].TabularAmplitude(name='Amp-1', timeSpan=STEP,smooth=SOLVER_DEFAULT, data=((0.0, 0.0), (cal_time1, 1.0)))
# mdb.models['Model-1'].Pressure(name='Load-1', createStepName='Step-1', 
	# region=region, distributionType=UNIFORM, field='', magnitude=pressure1)

##顶部施加单位载荷load
a = mdb.models['Model-1'].rootAssembly
r1 = a.referencePoints
refPoints2=(r1[rp1.id], )
region3=regionToolset.Region(referencePoints=refPoints2)
mdb.models['Model-1'].ConcentratedForce(name='load concetrat force', 
    createStepName='Step-1', region=region3, cf2=-1, distributionType=UNIFORM, 
    field='', localCsys=None)

##顶部进行约束
a = mdb.models['Model-1'].rootAssembly
r1 = a.referencePoints
refPoints1=(r1[rp1.id], )
region = a.Set(referencePoints=refPoints1, name='CylinderTop')
mdb.models['Model-1'].DisplacementBC(name='BC-top', createStepName='Step-1', 
    region=region, u1=0.0, u2=UNSET, u3=0.0, ur1=UNSET, ur2=UNSET, ur3=UNSET, 
    amplitude=UNSET, buckleCase=PERTURBATION_AND_BUCKLING, fixed=OFF, 
    distributionType=UNIFORM, fieldName='', localCsys=None)

##底部进行约束
a = mdb.models['Model-1'].rootAssembly
region = a.instances['Cylinder11-1'].sets['CylinderBot']
mdb.models['Model-1'].DisplacementBC(name='BC-bot', createStepName='Step-1', 
    region=region, u1=0.0, u2=0.0, u3=0.0, ur1=UNSET, ur2=UNSET, ur3=UNSET, 
    amplitude=UNSET, buckleCase=PERTURBATION_AND_BUCKLING, fixed=OFF, 
    distributionType=UNIFORM, fieldName='', localCsys=None)

# namejob='zhengzhi'+str(NN)
# p	=	mdb.models['Model-1'].parts['Cylinder11']
# mass2=p.getMassProperties()
# mass2=1000.0*mass2['mass']

# name_mass='MASS.txt'
# outfile_mass=open(name_mass,'w')
# outfile_mass.write(mass2)
# outfile_mass.close()

mdb.Job(name='JOb-danji', model='Model-1', description='', type=ANALYSIS, 
	atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
	memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
	explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
	modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
	scratch='', multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
mdb.jobs['JOb-danji'].submit(consistencyChecking=OFF)

mdb.jobs['JOb-danji'].waitForCompletion()
from odbAccess import *
odb=openOdb('JOb-danji.odb')
FF=odb.steps['Step-1']. frames[1]. description
odb.close()
EE=re.findall(r"\d+\.?\d*",FF)
EE1=10**float(EE[2])
EE2=float(EE[1])
EE3=EE2*EE1
mfile=open('FF_danji.txt','w')
mfile.write(''+str(EE3)+'\n')
mfile.close()



# pressure1=(0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
# FFF=(6.1797E4,6.7997E4,7.2846e4,7.6989e4,8.0112e4,8.3209e4,8.535e4,8.7306e4)
# Length1=len(pressure1)
# job11=('job2','job3','job4','job5','job6','job7','job8','job9')
# for ii in range(0,Length1):
	# print(ii)
	# print(job11[ii])
	# ##施加内压
	# Surfacename='CylinderSurface'
	# region = a.instances['Cylinder11-1'].surfaces[Surfacename]
	# # mdb.models['Model-1'].TabularAmplitude(name='Amp-1', timeSpan=STEP,smooth=SOLVER_DEFAULT, data=((0.0, 0.0), (cal_time1, 1.0)))
	# mdb.models['Model-1'].Pressure(name='Load-1', createStepName='Step-1', 
		# region=region, distributionType=UNIFORM, field='', magnitude=pressure1[ii])
	# ##顶部施加单位载荷load
	# a = mdb.models['Model-1'].rootAssembly
	# r1 = a.referencePoints
	# refPoints2=(r1[rp1.id], )
	# region3=regionToolset.Region(referencePoints=refPoints2)
	# mdb.models['Model-1'].ConcentratedForce(name='load concetrat force', 
		# createStepName='Step-1', region=region3, cf2=-FFF[ii]*1000, distributionType=UNIFORM, 
		# field='', localCsys=None)
	# ###	job	###################################################################
	# mdb.Job(name=job11[ii], model='Model-1', description='', type=ANALYSIS, 
		# atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
		# memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
		# explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
		# modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
		# scratch='', multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
	# mdb.jobs[job11[ii]].submit(consistencyChecking=OFF)




