function L_true=fun_likelihood(Ye,Xe,t,sigam,model_M)
    %直接贝叶斯校准求单个样本点的最大似然函数
    [Num_e,dim]=size(Ye);
    Xm=[Xe,t.*ones(Num_e,1)];
    Ym=predictor(Xm,model_M);
    L_true=prod((2*pi)^(-0.5)*(sigam^(-1)).*exp(-(Ye-Ym).^2./(2*sigam^2)));
end