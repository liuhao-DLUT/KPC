function ym=funM(x,t)
[N dim]=size(x);
global cases
%     if cases==1
%         ym=t.*x;
% else
    if cases==1
        ym=x.^t;
    elseif cases==2
        ym=t.^x;
    elseif cases==3
        ym=cos(t.*x);
    elseif cases==4
        ym=atan(t.*x);
    elseif cases==5
        ym=log(x+2)./log(t+2);
    end
end