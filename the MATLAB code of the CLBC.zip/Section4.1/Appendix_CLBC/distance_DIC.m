function [d]=distance_DIC(Y_obs,Y_sim)
% The new metric based on distance correlation and cosine similarity 
% The distance correlation pursuits experimental value and simulation value are most similar
% The cosine similarity pursuits experimental value and simulation value are closest
    [Ne dim]=size(Y_obs);
    d_correlation=1-(MDIC_XG(Y_obs,Y_sim));                                % calculating the distance correlation
%     d_pearson=1-abs(corr(Y_obs,Y_sim,'type','pearson'));
    d=d_correlation; 
end