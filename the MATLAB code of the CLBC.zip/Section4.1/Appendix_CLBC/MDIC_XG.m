function  R=fun_dic(X1,Y)
%�������ϵ��
[m dim]=size(X1);
B=funAzhuan(Y);
BB=B.^2;
VYY=mean(BB(:));
AX1=funAzhuan(X1);  
CXY=AX1.*B;
VXY=mean(CXY(:));
AA=AX1.^2; 
VXX=mean(AA(:));
if VYY==0||VXX==0
         R=0;
end
R=VXY/sqrt(VXX*VYY); 
   function A=funAzhuan(X)
%XΪM*1����
[m dim]=size(X);
for i=1:m
     for j=1:m
%          a(i,j)=abs(X(i,1)-X(j,1));
         a(i,j)=norm((X(i,1)-X(j,1)),dim);
     end
 end
     ak=mean(a,2);
     al=mean(a,1);
     adian=mean(a(:));
for i=1:m
      for j=1:m
          A(i,j)=a(i,j)-ak(i,1)-al(1,j)+adian;
      end
end