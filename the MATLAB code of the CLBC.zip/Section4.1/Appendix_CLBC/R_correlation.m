function R=R_correlation(Se,Sm,theta)
% The correlation coefficient is calculated based on Gaussian kernel function
% The dimension information for the input variable
[Num_M,dimXT]=size(Sm);
[Num_E,dimX]=size(Se);
% Normalize input variable 
% mSe = mean(Se);   sSe = std(Se);
% mSm = mean(Sm);   sSm = std(Sm);
% j = find(sSe == 0);
% if  ~isempty(j),  sSe(j) = 1; end
% j = find(sSm == 0);
% if  ~isempty(j),  sSm(j) = 1; end
% Se = (Se - repmat(mSe,Num_E,1)) ./ repmat(sSe,Num_E,1);
% Sm = (Sm - repmat(mSm,Num_M,1)) ./ repmat(sSm,Num_M,1);
% Calculating the correlation coefficient
R=ones(Num_E,Num_M);
for i=1:Num_E
   for j=1:Num_M
      d=Sm(j,:)-Se(i,:);
      R(i,j)=exp(sum(d.^2 .* (-theta(:).')));
   end
end
end