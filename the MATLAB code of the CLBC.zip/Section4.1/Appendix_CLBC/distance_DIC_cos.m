function [d]=distance_DIC_manhattan(Y_obs,Y_sim)
% The new metric based on distance correlation and cosine similarity 
% The distance correlation pursuits experimental value and simulation value are most similar
% The cosine similarity pursuits experimental value and simulation value are closest
    d_correlation=1-(MDIC_XG(Y_obs,Y_sim));                                % calculating the distance correlation
    d_cosine=1-sum(Y_obs.*Y_sim)/(norm(Y_obs)*norm(Y_sim));                % Calculating the cosine similarity
    d=d_correlation*d_cosine;                                              % Takeing the product of the two as the new metric, taking into account both distance and similarity
%     d_manhattan=sum(abs(Ye-Y_predictor));
%     d=d_correlation*d_manhattan;
end