function ye=funE(x)
[N dim]=size(x);
global cases
    if cases==1
        ye=2.*x.^1.7+1.5;
    elseif cases==2
        ye=2.*1.7.^x+1.5;
    elseif cases==3
        ye=2.*cos(1.7.*x)+1.5;
    elseif cases==4
        ye=2.*atan(1.7.*x)+1.5;
    elseif cases==5
        ye=2.*log(x+2)./log(1.7+2)+1.5;
    end
end