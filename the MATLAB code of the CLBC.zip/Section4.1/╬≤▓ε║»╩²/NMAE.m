function ERRnmae=NMAE(YX,Yreal,X)
  [N dim]=size(YX);
  for i=1:N
     ERR(i)=max(abs((Yreal(i,1)-YX(i,1))/Yreal(i,1)));
  end
  ERRnmae=max(ERR);
end