function ErrorR2=ERRORrr2 (YX,Yreal,X)
 [n,m]=size(X);
 a=(Yreal-YX).^2;
 A=sum(a(:));
 b=(Yreal-mean(Yreal)).^2;
 B=sum(b(:));
 ErrorR2=1-A/B;
end
