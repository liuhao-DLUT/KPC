function ErrorMAX=ERRORmax(YX,Yreal,X)
[n,m]=size(X);
A=abs(YX-Yreal);
B=sum(Yreal)/n;
ErrorMAX=max(100.*A/B);
end
