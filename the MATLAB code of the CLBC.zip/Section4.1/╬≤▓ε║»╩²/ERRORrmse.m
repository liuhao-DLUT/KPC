function ErrorRmse=ERROErmse(YX,Yreal,X)
[n,m]=size(X);
A=sqrt(sum((YX-Yreal).^2)/n);
B=sum(Yreal)/n;
ErrorRmse=100*A/B;
end
