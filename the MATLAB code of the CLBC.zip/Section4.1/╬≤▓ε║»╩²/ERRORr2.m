function ErrorR2=ERRORr2 (YX,Yreal,X)
 [n,m]=size(X);
 a=(Yreal-YX).^2;
 A=sum(a(:));
 b=sum(Yreal.^2);
 b1=(sum(Yreal(:)))^2;
 B=b-b1/n;
 ErrorR2=1-A./B;
end

