function [d]=distance_manhattan(Y_obs,Y_sim)
% 基于 Manhattan距离
[Ne dim]=size(Y_obs);
Ycha=abs((Y_obs-Y_sim));
d=sum(Ycha);
end