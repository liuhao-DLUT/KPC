function L_true=fun_likelihood(Ye,Xe,t,sigam,model_M)
    %直接贝叶斯校准求单个样本点的�?大似然函�?
    [Num_e,dim]=size(Ye);
    Xm=[Xe,t.*ones(Num_e,1)];
    Ym=predictor(Xm,model_M);
    sigama=0.2;
    L_true=prod((2*pi)^(-0.5)*(sigama^(-1)).*exp(-(Ye-Ym).^2./(2*sigama^2)));
end