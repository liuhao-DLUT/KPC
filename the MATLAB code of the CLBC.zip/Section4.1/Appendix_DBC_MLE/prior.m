function P = prior(Phi,Phi_min,Phi_max)
    if Phi >= Phi_min && Phi <= Phi_max
        P = 1 / (Phi_max - Phi_min);
    else
        P = 0;
    end
end