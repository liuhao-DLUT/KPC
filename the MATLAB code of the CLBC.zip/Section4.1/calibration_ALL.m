%% KOH-ABC calibration frame
clear all;clc;close all;warning('off');
No=3;
% The framework<3��calibration> is mainly divided into four modules: 
% 1. Build the surrogate model of the simulation model
% 2. Approximate Bayesian parameter calibration (t) based on a new metric
% 3. Estimating Scale factor (ro) and discrepancy term surrogate models based on maximum likelihood function
% 4. Prediction
%% 1��parameter setting
global cases
dim_x=1;dim_t=1;                                                           % Dimensions of design variables x and calibration variables t
X=[0 3];T=[0 3];                                                           % Range of parameters for design variables and calibration variables
t_intial=1.*ones(1,dim_t);                                                 % Calibration parameter initial value
Num_m=50;Num_e=3;                                                          % Simulation model and true test sample points
cases=5;                                                                   % The number of case
% True distribution of experimental observations: taking the Gaussian distribution as an example
distribution_type='Gaussian';                                              % The distribution type of the actual observed value, for example: Gaussian distribution
sigma_obs=0.01;                                                             % The variance of the Gaussian distribution,The mean is Ye
%% 2��Calculate or import simulation response values and experimental observations
% Parameter meaning: 
% Ye:Experimental observations   Se:The design variable corresponding to the experimental observation
% Ym:Simulation result           Sm:Design variables and calibration parameters corresponding to the simulation model
Sm=lhsdesign(Num_m,dim_x+dim_t).*([X(:,2)',T(:,2)']-[X(:,1)',T(:,1)'])+[X(:,1)',T(:,1)'];
% Sm=xlsread('Sm_train.xls');
% The sample points of simulation model are extracted based on Latin Hypercube sampling
Ym=funM(Sm(:,1:dim_x),Sm(:,dim_x+1:end));                                  % Calculate the simulation response value
Se=(linspace(0,1,Num_e)*(X(:,2')-X(:,1)')+X(:,1)')';                           % The sample points of Experimental model are extracted based on Latin Hypercube sampling
% Se=lhsdesign(Num_e,dim_x)*(X(:,2')-X(:,1)')+X(:,1)';
Ye=funE(Se);                                                               % Calculate the Experimental response value
Ye=normrnd(Ye,sigma_obs);                                                % Gaussian distribution
X_ce=lhsdesign(1000,dim_x)*(X(:,2')-X(:,1)')+X(:,1)';
Y_ce=funE(X_ce);
data_M=[Sm,Ym];
data_E=[Se,Ye];
data_ce=[X_ce];
%% #1��DBC-LME-Calibration
% ����ģ��GP-----------------------------------------------------------------------------------
theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
[model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);
% ��Ҷ˹У׼-----------------------------------------------------------------------------------
likelihood=@(t)fun_likelihood(Ye,Se,t,sigma_obs,model_M);
post =@(t) likelihood (t) * prior(t,T(1,1),T(1,2));
MLE=@(t) likelihood (t) * prior(t,T(1,1),T(1,2))*(-1);
[DBC_MLE_t,MLE_max]=ga(MLE,1,[],[],[],[],T(:,1),T(:,2));
% Ԥ��-----------------------------------------------------------------------------------
S_ce=[X_ce,DBC_MLE_t.*ones(1000,1)];
Y_ce_MLE=predictor(S_ce,model_M);
DBC_MLE_R2=ERRORr2(Y_ce_MLE,Y_ce,X_ce);
DBC_MLE_RMSE=ERRORrmse(Y_ce_MLE,Y_ce,X_ce);
% ��ͼ�����ݴ洢-----------------------------------------------------------------------------------
t=(T(:,1)':0.03:T(:,2)')';
prob = ones(length(t), 1);
for i = 1:1:length(t)
    prob(i) = post(t(i));
end
prob = prob / trapz(t, prob);
% ����ֲ�
draw_DBC_MLE=[t,prob];
figure(101)
plot(t, prob);
% Ԥ��ͼ
% draw fig
xx=(X(1):0.01:X(2))';
fe=[];fm=[];
[n,dim]=size(xx);
for i=1:size(xx)
    fe(i,1)=funE(xx(i));
    fm(i,1)=funM(xx(i),1.7);
end
aa=predictor([xx,DBC_MLE_t*ones(n,1)],model_M);
figure(102)
hold on
plot(xx,fe,'b','Linewidth',1)
plot(xx,fm,'--b','Linewidth',1)
plot(xx,aa,'--r','Linewidth',1)
legend('��ʵ��������','����ģ��','Ԥ��ģ��')
xx_DBC_MLE=[xx,fe,fm,aa];
output_DBC_MLE=[DBC_MLE_t,DBC_MLE_R2,DBC_MLE_RMSE]
% %% #2��DBC-ABC-Calibration
% % ����ģ��GP-----------------------------------------------------------------------------------
%  theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
% [model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);
% % ABC  У׼-----------------------------------------------------------------------------------
% N=1E5;tolerance=6;                                                       % Sampling number and tolerance of ABC
% T_gather=[];t=[];                                                              % The sample set that satisfies the tolerance requirement
% for i=1:N
% %     Y_obs=Ye;
% %     t=rand(1)*(T(:,2)'-T(:,1)')+T(:,1)';  
% %     Y_sim=predictor([Se,t.*ones(Num_e,1)],model_M);
% %     d=distance_manhattan(Y_obs,Y_sim);
% %     if d<tolerance                                                         % Determines whether the current calibration parameters is accepted
% %         T_gather=[T_gather;t];
% %     end 
%     Y_obs=Ye;
%     t(i)=rand(1)*(T(:,2)'-T(:,1)')+T(:,1)';                                   
%     Y_sim=predictor([Se,t(i).*ones(Num_e,1)],model_M);                     % Under the current calibration parameters t, the simulation response corresponding to the test observation value
%     d(i)=distance_manhattan(Y_obs,Y_sim);           
% end
% distance_sort=[d',t'];[~,idx]=sort(distance_sort(:,1));distance_sort=distance_sort(idx,:);
% T_gather=distance_sort(1:N/1000,2); 
% [M N]=size(T_gather);
% [f_ABC,t_idx]=ksdensity(T_gather,'Bandwidth',0.1);                         % Get a probability density estimate
% DBC_ABC_t=t_idx(find(f_ABC==max(f_ABC)));                               % Get the calibration parameters
% % Ԥ��-----------------------------------------------------------------------------------
% S_ce=[X_ce,DBC_ABC_t.*ones(1000,1)];
% Y_ce_ABC=predictor(S_ce,model_M);
% DBC_ABC_R2=ERRORr2(Y_ce_ABC,Y_ce,X_ce);
% DBC_ABC_RMSE=ERRORrmse(Y_ce_ABC,Y_ce,X_ce);
% % ��ͼ�����ݴ洢-----------------------------------------------------------------------------------
% % ����ֲ�
% figure(201)
% plot(t_idx,f_ABC);
% % 输出数据
% draw_DBC_ABC=[t_idx',f_ABC'];
% xlim([0,3])
% % Ԥ��ͼ
% % draw fig
% xx=(X(1):0.01:X(2))';
% fe=[];fm=[];
% [n,dim]=size(xx);
% for i=1:size(xx)
%     fe(i,1)=funE(xx(i));
%     fm(i,1)=funM(xx(i),1.7);
% end
% aa=predictor([xx,DBC_ABC_t*ones(n,1)],model_M);
% figure(202)
% hold on
% plot(xx,fe,'b','Linewidth',1)
% plot(xx,fm,'b','Linewidth',1)
% plot(xx,aa,'--r','Linewidth',1)
% legend('��ʵ��������','����ģ��','Ԥ��ģ��')
% xx_DBC_ABC=[xx,fe,fm,aa];
% output_DBC_ABC=[DBC_ABC_t,DBC_ABC_R2,DBC_ABC_RMSE]
%% #3��KOH-Calibration
% module1����ģ��GP-----------------------------------------------------------------------------------
theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
[model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);    
parameter_GP1=struct('theta_M',model_M.theta,'sig_M',model_M.sigma2,'beta1',model_M.beta); 
% module2ƫ���-----------------------------------------------------------------------------------
[Y_M_predictor,s_m]=predictor([Se,t_intial.*ones(Num_e,dim_t)],model_M); 
MLE_GP2_obj=@(t)MLE_discrepancy(t,Sm,Se,Ye,Y_M_predictor,parameter_GP1,model_M,sigma_obs,t_intial); 
[parameter_E,MLE_GP]= ga(MLE_GP2_obj,2+dim_x,[],[],[],[],[0,1e-5,1e-5*ones(1,dim_x)],[10,1^10,60*ones(1,dim_x)]);
ro=parameter_E(1);                                                         
sigma_discrepancy=parameter_E(2);                                          
theta_discrepancy=parameter_E(3:end);                                      
parameter_GP2=struct('theta_E',theta_discrepancy,'ro',ro,'sigma_obs',sigma_obs,'sig_E',sigma_discrepancy);
% module3У׼-----------------------------------------------------------------------------------
calib_obj=@(calibration_t)MLE_calibration(calibration_t,Sm,Se,Ym,Ye,parameter_GP1,parameter_GP2,model_M);  
[t,MAX_LM]= ga(calib_obj,dim_t,[],[],[],[],T(:,1)',T(:,2)');
KOH_t=t;
[Y_M_predictor,s_m]=predictor([Se,KOH_t.*ones(Num_e,dim_t)],model_M); 
[model_discrepancy,~]=dacefit(Se, Ye-ro.*Y_M_predictor, @regpoly0, @corrgauss,theta_discrepancy);
% module4Ԥ��
S_ce=[X_ce,KOH_t.*ones(1000,1)];
Ym_ce_KOH=predictor(S_ce,model_M);
[Y_discrepancy,~]=predictor(X_ce,model_discrepancy);
Ye_ce_KOH=Ym_ce_KOH.*ro+Y_discrepancy;
KOH_R2=ERRORr2(Ye_ce_KOH,Y_ce,X_ce);
KOH_RMSE=ERRORrmse(Ye_ce_KOH,Y_ce,X_ce);
% ��ͼ
% MAX_LM
prob1=[];
t0=(T(:,1)':0.03:T(:,2)')';
global Phi_max Phi_min
Phi_min=T(:,1);Phi_max=T(:,2);
for i = 1:1:length(t0) 
      prob1(i) =-calib_obj(t0(i))*prior(t0(i),T(:,1),T(:,2));
end
prob1=prob1';
prob2 =prob1  / trapz(t0, prob1);
figure(301)
plot(t0, prob2);
draw_KOH=[t0, prob2];
% draw fig
xx=(X(1):0.01:X(2))';
fe=[];fm=[];
[n,dim]=size(xx);
for i=1:size(xx)
    fe(i,1)=funE(xx(i));
    fm(i,1)=funM(xx(i),1.7);
end
aa=predictor([xx,KOH_t*ones(n,1)],model_M);
[bb,~]=predictor(xx,model_discrepancy);
cc=aa*ro+bb;
figure(302)
hold on
plot(xx,fe,'b','Linewidth',1)
plot(xx,cc,'--b','Linewidth',1)
plot(xx,fm,'r','Linewidth',1)
plot(xx,aa,'--r','Linewidth',1)
plot(xx,fe-2.*fm,'k','Linewidth',1)
plot(xx,bb,'--k','Linewidth',1)
legend('��ʵ��������','��ʵԤ��ģ��','����ģ��','Ԥ�����ģ��','ƫ��ģ��','Ԥ��ƫ��ģ��')
xx_KOH=[xx,fe,fm,aa,bb,cc];
output_KOH=[KOH_t,KOH_R2,KOH_RMSE,ro]
%% #4��OBC-Calibration
theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
[model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);   
[Y_M_predictor,s_m]=predictor([Se,t_intial.*ones(Num_e,dim_t)],model_M); 
t_ro_obj=@(t)OBC_calibration(t,model_M,Se,Sm,Ye);
[parameter_t_ro,MLE_GP]= ga(t_ro_obj,dim_t,[],[],[],[],[T(:,1)'],[T(:,2)']);
ro=1;                                                     % the scale factor (ro)
OBC_t=parameter_t_ro;  
[Y_M_predictor,s_m]=predictor([Se,OBC_t.*ones(Num_e,dim_t)],model_M); 
theta0_E=ones(1,dim_x);lob_E=1e-8.*ones(1,dim_x);up_E=100.*ones(1,dim_x);
[model_discrepancy,~]=dacefit(Se, Ye-ro.*Y_M_predictor, @regpoly0, @corrgauss,theta0_E,lob_E,up_E);
% Ԥ��
[Y_M,~]=predictor([X_ce,OBC_t.*ones(1000,dim_t)],model_M);       % The simulated predicted value of the test set
[Y_discrepancy,~]=predictor(X_ce,model_discrepancy);                     % The predicted value of the deviation term
Y_predictor=Y_M.*ro+Y_discrepancy;                                         % The predicted value of the experiment
OBC_R2=ERRORr2(Y_predictor,Y_ce,X_ce);                                      % r2
OBC_RMSE=ERRORrmse(Y_predictor,Y_ce,X_ce);                                  % Mean square error analysis
% ��ͼ
LME=@(t)OBC_MLE(t,model_M,model_discrepancy,Se,Ye,ro,sigma_obs) * prior(t,T(1,1),T(1,2));
t=linspace(T(:,1)', T(:,2)', 100);
prob = ones(1, length(t));
for i = 1:1:length(t)
    prob(i) = LME(t(i));
end
prob = prob / trapz(t, prob);
% max
T_max = t(prob == max(prob));
% 画图
figure(401)
plot(t, prob)
% draw
xx=(X(1):0.01:X(2))';
fe=[];fm=[];
[n,dim]=size(xx);
for i=1:size(xx)
    fe(i,1)=funE(xx(i));
    fm(i,1)=funM(xx(i),1.7);
end
aa=predictor([xx,OBC_t*ones(n,1)],model_M);
[bb,~]=predictor(xx,model_discrepancy);
cc=aa*ro+bb;
figure(402)
hold on
plot(xx,fe,'b','Linewidth',1)
plot(xx,cc,'--b','Linewidth',1)
plot(xx,fm,'r','Linewidth',1)
plot(xx,aa,'--r','Linewidth',1)
plot(xx,fe-2.*fm,'k','Linewidth',1)
plot(xx,bb,'--k','Linewidth',1)
legend('��ʵ��������','��ʵԤ��ģ��','����ģ��','Ԥ�����ģ��','ƫ��ģ��','Ԥ��ƫ��ģ��')
xx_OBC=[xx,fe,fm,aa,bb,cc];
draw_OBC=[t',prob'];
output_OBC=[OBC_t,OBC_R2,OBC_RMSE,ro]
%% #5��LFC-Calibration
%% Module 1: Build the surrogate model of the simulation model
theta0_M=ones(1,dim_x+dim_t);lob_M=1e-8.*ones(1,dim_x+dim_t);up_M=100.*ones(1,dim_x+dim_t);
% The initial value of the hyperparameter of the surrogate model and its upper and lower limits
[model_M,~]=dacefit(Sm, Ym, @regpoly0, @corrgauss,theta0_M,lob_M,up_M);    % Build the Kriging surrogate model of the simulation model
parameter_GP1=struct('theta_M',model_M.theta,'sig_M',model_M.sigma2);      % Summary of parameters of the simulation surrogate model
%% Module 2: Approximate Bayesian parameter calibration (t) based on a new measure
% The ABC algorithm is detailed in the paper "Approximate Bayesian
% Computational methodsfor the inference of unknown parameters". Here a
% Rejection ABC method is taken.
N=1E5;tolerance=1E-3;                                                     % Sampling number and tolerance of ABC
T_gather=[];                                                                % The sample set that satisfies the tolerance requirement
for i=1:N
    Y_obs=Ye;
    t(i)=rand(1)*(T(:,2)'-T(:,1)')+T(:,1)';                                   
    % A sample point is extracted based on the prior distribution type of calibration parameters
    % the algorithm generally assumes uniform distribution.
    Y_sim=predictor([Se,t(i).*ones(Num_e,1)],model_M);                     % Under the current calibration parameters t, the simulation response corresponding to the test observation value
%     d(i)=distance_DIC_cos(Y_obs,Y_sim);                                    % A double metric based on distance correlation and complementary similarity
    d(i)=distance_DIC(Y_obs,Y_sim);                                    % A double metric based on distance correlation and complementary similarity
    %     if d<tolerance                                                       % Determines whether the current calibration parameters is accepted
%         T_gather=[T_gather;t];
%     end  
end
distance_sort=[d',t'];[~,idx]=sort(distance_sort(:,1));distance_sort=distance_sort(idx,:);
% Ordering the measure of approximate Bayesian computation from smallest to largest
T_gather=distance_sort(1:N/500,2);                                         % Taking the first n=100 measure to satisfy the requirement

[f_ABC,t_idx]=ksdensity(T_gather,'Bandwidth',0.1);                         % Get a probability density estimate
LFC_t=t_idx(find(f_ABC==max(f_ABC)));                               % Get the calibration parameters 
% figure:A posterior distribution of calibration parameters is obtained
figure(501)
hold on
% bar(t_idx,f_ABC)
plot(t_idx,f_ABC)
hold off 
%% Module 3: Estimating Scale factor (ro) and discrepancy term surrogate model based on maximum likelihood function
% This module estimates Scale factor (ro) and discrepancy term surrogate model hyperparameters
% Parameter meaning: 
% ro:Scale factor
% theta_discrepancy:the hyperparameters of discrepancy term surrogate model
% sigma_discrepancy:the model variance of discrepancy term surrogate model
[Y_M_predictor,s_m]=predictor([Se,LFC_t.*ones(Num_e,dim_t)],model_M); 
% Simulation prediction results under calibration parameters
MLE_GP2_obj=@(t)MLE_discrepancy(t,Sm,Se,Ye,Y_M_predictor,parameter_GP1,model_M,sigma_obs,LFC_t); 
% likelihood function
[parameter_E,~]= ga(MLE_GP2_obj,2+dim_x,[],[],[],[],[0,1e-5,1e-5*ones(1,dim_x)],[10,10^10,60*ones(1,dim_x)]);
% The maximum likelihood function is optimized to obtain the scale factor and the hyperparameters of discrepancy term surrogates model
ro=parameter_E(1);                                                          % the scale factor (ro)
sigma_discrepancy=parameter_E(2);                                          % sigma_discrepancy
theta_discrepancy=parameter_E(3:end);                                      % theta_discrepancy
[model_discrepancy,~]=dacefit(Se, Ye-ro.*Y_M_predictor, @regpoly0, @corrgauss,theta_discrepancy);
% Construct the discrepancy term surrogate model
%% Module 4: Prediction                                                  % Calculating the true response of the test set
[Y_M,~]=predictor([X_ce,LFC_t.*ones(1000,dim_t)],model_M);       % The simulated predicted value of the test set
[Y_discrepancy,~]=predictor(X_ce,model_discrepancy);                     % The predicted value of the deviation term
Y_predictor=Y_M.*ro+Y_discrepancy;                                         % The predicted value of the experiment
LFC_R2=ERRORr2(Y_predictor,Y_ce,X_ce);                                      % r2
LFC_RMSE=ERRORrmse(Y_predictor,Y_ce,X_ce);                                 % Mean square error analysis
%% draw fig
figure(501)
plot(t_idx,f_ABC)
draw_LFC=[t_idx,f_ABC];
% draw
xx=(X(1):0.01:X(2))';
fe=[];fm=[];
[n,dim]=size(xx);
for i=1:size(xx)
    fe(i,1)=funE(xx(i));
    fm(i,1)=funM(xx(i),1.7);
end
aa=predictor([xx,LFC_t*ones(n,1)],model_M);
[bb,~]=predictor(xx,model_discrepancy);
cc=aa*ro+bb;
figure(502)
hold on
plot(xx,fe,'b','Linewidth',1)
plot(xx,cc,'--b','Linewidth',1)
plot(xx,fm,'r','Linewidth',1)
plot(xx,aa,'--r','Linewidth',1)
plot(xx,fe-2.*fm,'k','Linewidth',1)
plot(xx,bb,'--k','Linewidth',1)
legend('��ʵ��������','��ʵԤ��ģ��','����ģ��','Ԥ�����ģ��','ƫ��ģ��','Ԥ��ƫ��ģ��')
xx_CLC=[xx,fe,fm,aa,bb,cc];
draw_CLC=[t_idx',f_ABC'];
output_CLC=[LFC_t,LFC_R2,LFC_RMSE,ro]
%% ����
output=[output_DBC_MLE,1;output_KOH;output_OBC;output_CLC];

%% ���ݴ洢
% ������
outwork=['G:\matlab\У׼�㷨\#paper��KOH_ABC\��0227_Section4.1\���ݴ洢\case',num2str(cases),'\No',num2str(No),'\'];
xlswrite([outwork, '����ģ��������.xls'],data_M);
xlswrite([outwork, '��Ӧ�۲�����������.xls'],data_E);
xlswrite([outwork, '���Ȳ���������.xls'],data_ce);
% У׼�������
xlswrite([outwork,'У׼���.xls'],output);    
% ����ֲ�
% DBC_MLE
xlswrite([outwork,'1-1DBC_MLE_��ͼ����.xls'],xx_DBC_MLE);
xlswrite([outwork,'2-1DBC_MLE����ֲ�.xls'],draw_DBC_MLE);
% KOH
xlswrite([outwork,'1-3KOH_��ͼ����.xls'],xx_KOH);
xlswrite([outwork,'2-3KOH����ֲ�.xls'],draw_KOH);
% OBC
xlswrite([outwork,'1-4OBC_��ͼ����.xls'],xx_OBC);
xlswrite([outwork,'2-4OBC����ֲ�.xls'],draw_OBC);
% CLC
xlswrite([outwork,'1-5CLC_��ͼ����.xls'],xx_CLC);
xlswrite([outwork,'2-5CLC����ֲ�.xls'],draw_CLC); 

    
  










