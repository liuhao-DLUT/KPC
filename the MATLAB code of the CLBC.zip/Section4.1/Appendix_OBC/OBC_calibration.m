function d=OBC_calibration(t,model_M,Se,Sm,Ye)
    %���һ��Ϊro
    %校准t �?大化试验值和仿真�?
    [Num_M,dimXT]=size(Sm);
    [Num_E,dimX]=size(Se);
    dimT=dimXT-dimX;
    calibration_t=t;
    ro=1;
    S=[Se,calibration_t.*ones(Num_E,dimT)];
    Y_predictor=predictor(S,model_M);
    %Manhattan distance
    d=sum(abs(Ye-ro.*Y_predictor));
%     d=1-sum(Ye.*ro.*Y_predictor)/(norm(Ye)*norm(ro.*Y_predictor));
end