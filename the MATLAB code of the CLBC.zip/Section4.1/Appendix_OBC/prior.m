function P = prior(t,t_min,t_max)
    if t >= t_min && t <= t_max
        P = 1 / (t_max - t_min);
    else
        P = 0;
    end
end