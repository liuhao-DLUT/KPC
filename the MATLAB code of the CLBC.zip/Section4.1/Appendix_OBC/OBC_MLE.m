function   L_true=OBC_MLE(t,model_M,model_discrepancy,Se,Ye,ro,sigma)
    %����
    [Num_E dim_t]=size(Se);
    S=[Se,t.*ones(Num_E,dim_t)];
    [Y_m,~]=predictor(S,model_M);  
    [Y_discrepancy,~]=predictor(Se,model_discrepancy);
    Y_mean=Y_m.*ro+Y_discrepancy;
    L_true=prod((2*pi)^(-0.5)*(sigma^(-1)).*exp(-(Ye-Y_mean).^2./(2*sigma^2)));
end